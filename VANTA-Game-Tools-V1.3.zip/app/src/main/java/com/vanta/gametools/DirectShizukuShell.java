package com.vanta.gametools;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import rikka.shizuku.Shizuku;

/**
 * Direct shell backend for Shizuku 13.x.
 *
 * UserService is the preferred public API for complex long-running privileged
 * code, but some OEM/ROM combinations fail to start app_process UserServices.
 * For VANTA we mainly need short shell commands (dumpsys/cmd/settings/pidof),
 * so we use Shizuku's remote-process implementation as a compatibility
 * backend and keep UserService as a fallback.
 */
public final class DirectShizukuShell {
    private static final int MAX_OUTPUT_CHARS = 700_000;
    private static final long TIMEOUT_SECONDS = 12L;
    private static final ExecutorService IO = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "vanta-shizuku-io");
        t.setDaemon(true);
        return t;
    });

    private static volatile Method newProcessMethod;
    private static volatile boolean methodResolved;
    private static volatile String lastError = "";

    private DirectShizukuShell() {}

    private static Method resolveMethod() {
        if (methodResolved) return newProcessMethod;
        synchronized (DirectShizukuShell.class) {
            if (methodResolved) return newProcessMethod;
            methodResolved = true;
            try {
                Method method = Shizuku.class.getDeclaredMethod(
                        "newProcess",
                        String[].class,
                        String[].class,
                        String.class
                );
                method.setAccessible(true);
                newProcessMethod = method;
                lastError = "";
            } catch (Throwable t) {
                newProcessMethod = null;
                lastError = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
            }
            return newProcessMethod;
        }
    }

    public static boolean available() {
        try {
            if (!Shizuku.pingBinder()) return false;
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;
            int uid = Shizuku.getUid();
            return (uid == 0 || uid == 2000) && resolveMethod() != null;
        } catch (Throwable t) {
            lastError = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
            return false;
        }
    }

    public static int uid() {
        try { return available() ? Shizuku.getUid() : -1; }
        catch (Throwable t) { return -1; }
    }

    public static String lastError() {
        return lastError == null ? "" : lastError;
    }

    public static void reset() {
        methodResolved = false;
        newProcessMethod = null;
        lastError = "";
    }

    public static CommandResult exec(String command) {
        if (command == null || command.trim().isEmpty()) {
            return new CommandResult(2, "Comando vazio");
        }
        if (!available()) {
            String why = lastError();
            return new CommandResult(-991, "Shell direto do Shizuku indisponível" + (why.isEmpty() ? "" : ": " + why));
        }

        Process process = null;
        Future<String> stdoutFuture = null;
        Future<String> stderrFuture = null;
        try {
            Method method = resolveMethod();
            if (method == null) return new CommandResult(-990, lastError());

            String[] argv = new String[]{"sh", "-c", command};
            Object remote = method.invoke(null, new Object[]{argv, null, null});
            if (!(remote instanceof Process)) {
                return new CommandResult(-989, "Shizuku retornou processo incompatível");
            }
            process = (Process) remote;
            final Process p = process;
            stdoutFuture = IO.submit(() -> readBounded(p.getInputStream()));
            stderrFuture = IO.submit(() -> readBounded(p.getErrorStream()));

            boolean done = process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            if (!done) {
                try { process.destroy(); } catch (Throwable ignored) {}
                cancel(stdoutFuture);
                cancel(stderrFuture);
                return new CommandResult(-999, "Timeout após " + TIMEOUT_SECONDS + " s");
            }

            int code = process.exitValue();
            String stdout = getFuture(stdoutFuture);
            String stderr = getFuture(stderrFuture);
            String output;
            if (stdout.isEmpty()) output = stderr;
            else if (stderr.isEmpty()) output = stdout;
            else output = stdout + "\n" + stderr;
            lastError = "";
            return new CommandResult(code, output);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            lastError = cause.getClass().getSimpleName() + ": " + String.valueOf(cause.getMessage());
            return new CommandResult(-988, lastError);
        } catch (Throwable t) {
            lastError = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
            return new CommandResult(-987, lastError);
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    private static String readBounded(InputStream stream) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int n;
            while ((n = reader.read(buffer)) >= 0) {
                if (n == 0) continue;
                int room = MAX_OUTPUT_CHARS - out.length();
                if (room <= 0) {
                    out.append("\n[saída truncada pelo VANTA]");
                    break;
                }
                out.append(buffer, 0, Math.min(n, room));
            }
        }
        return out.toString().trim();
    }

    private static String getFuture(Future<String> future) {
        if (future == null) return "";
        try { return future.get(2, TimeUnit.SECONDS); }
        catch (Throwable t) {
            future.cancel(true);
            return "";
        }
    }

    private static void cancel(Future<String> future) {
        if (future != null) future.cancel(true);
    }
}
