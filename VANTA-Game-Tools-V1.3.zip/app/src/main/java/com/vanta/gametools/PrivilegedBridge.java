package com.vanta.gametools;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.SystemClock;

import java.util.concurrent.CopyOnWriteArrayList;

import rikka.shizuku.Shizuku;

public final class PrivilegedBridge {
    public interface StateListener { void onStateChanged(); }

    public static final int REQUEST_CODE = 4901;
    private static final long BIND_TIMEOUT_MS = 8000L;
    private static volatile boolean initialized;
    private static volatile boolean binding;
    private static volatile long bindingStartedAt;
    private static volatile IPrivilegedService service;
    private static volatile int remoteUid = -1;
    private static volatile String lastError = "";
    private static Context appContext;
    private static Shizuku.UserServiceArgs userServiceArgs;
    private static final CopyOnWriteArrayList<StateListener> listeners = new CopyOnWriteArrayList<>();

    private PrivilegedBridge() {}

    private static final Shizuku.OnBinderReceivedListener BINDER_RECEIVED = () -> {
        DirectShizukuShell.reset();
        binding = false;
        bindingStartedAt = 0L;
        lastError = "";
        // UserService is now optional. Try it in the background, but VANTA can
        // operate immediately through the direct shell backend.
        bindIfPossible();
        notifyState();
    };

    private static final Shizuku.OnBinderDeadListener BINDER_DEAD = () -> {
        service = null;
        remoteUid = -1;
        binding = false;
        bindingStartedAt = 0L;
        lastError = "Binder do Shizuku desconectado";
        DirectShizukuShell.reset();
        notifyState();
    };

    private static final Shizuku.OnRequestPermissionResultListener PERMISSION_RESULT = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE && grantResult == PackageManager.PERMISSION_GRANTED) {
            lastError = "";
            DirectShizukuShell.reset();
            bindIfPossible();
        }
        notifyState();
    };

    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            IPrivilegedService candidate = IPrivilegedService.Stub.asInterface(binder);
            try {
                int uid = candidate.uid();
                if (uid != 0 && uid != 2000) {
                    service = null;
                    remoteUid = uid;
                    lastError = "UserService conectado com UID inesperado: " + uid;
                } else {
                    service = candidate;
                    remoteUid = uid;
                    lastError = "";
                }
            } catch (Throwable t) {
                service = null;
                remoteUid = -1;
                lastError = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
            }
            binding = false;
            bindingStartedAt = 0L;
            notifyState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
            remoteUid = -1;
            binding = false;
            bindingStartedAt = 0L;
            lastError = "UserService desconectado";
            notifyState();
        }
    };

    public static synchronized void init(Context context) {
        if (initialized) return;
        appContext = context.getApplicationContext();
        userServiceArgs = new Shizuku.UserServiceArgs(new ComponentName(appContext, PrivilegedService.class))
                .daemon(false)
                .tag("vanta_shell_service_v13")
                .processNameSuffix("vanta_shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE);
        Shizuku.addBinderReceivedListenerSticky(BINDER_RECEIVED);
        Shizuku.addBinderDeadListener(BINDER_DEAD);
        Shizuku.addRequestPermissionResultListener(PERMISSION_RESULT);
        initialized = true;
        if (hasPermission()) bindIfPossible();
    }

    public static void addStateListener(StateListener listener) {
        if (listener != null) listeners.addIfAbsent(listener);
    }

    public static void removeStateListener(StateListener listener) {
        listeners.remove(listener);
    }

    private static void notifyState() {
        for (StateListener listener : listeners) {
            try { listener.onStateChanged(); } catch (Throwable ignored) {}
        }
    }

    public static boolean isBinderAlive() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    public static boolean hasPermission() {
        if (!isBinderAlive()) return false;
        try { return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    /**
     * Ready means VANTA can execute privileged shell commands. Direct Shizuku
     * remote-process support is enough; UserService is no longer mandatory.
     */
    public static boolean isReady() {
        if (!hasPermission()) return false;
        if (DirectShizukuShell.available()) return true;

        IPrivilegedService s = service;
        if (s == null) return false;
        try {
            int uid = s.uid();
            remoteUid = uid;
            return uid == 0 || uid == 2000;
        } catch (Throwable t) {
            service = null;
            remoteUid = -1;
            binding = false;
            bindingStartedAt = 0L;
            lastError = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
            return false;
        }
    }

    public static int serviceUid() {
        int direct = DirectShizukuShell.uid();
        if (direct == 0 || direct == 2000) return direct;
        return remoteUid;
    }

    public static boolean isBinding() {
        if (binding && bindingStartedAt > 0L && SystemClock.elapsedRealtime() - bindingStartedAt > BIND_TIMEOUT_MS) {
            recoverStuckBinding();
        }
        return binding;
    }

    public static int shizukuUid() {
        if (!isBinderAlive()) return -1;
        try { return Shizuku.getUid(); } catch (Throwable t) { return -1; }
    }

    public static void requestPermission() {
        if (!isBinderAlive()) return;
        if (hasPermission()) {
            DirectShizukuShell.reset();
            bindIfPossible();
            notifyState();
            return;
        }
        try { Shizuku.requestPermission(REQUEST_CODE); }
        catch (Throwable t) { lastError = String.valueOf(t.getMessage()); }
    }

    /** Optional compatibility backend; direct shell remains primary. */
    public static synchronized void bindIfPossible() {
        if (!initialized || service != null || !hasPermission()) return;
        if (binding) {
            if (bindingStartedAt > 0L && SystemClock.elapsedRealtime() - bindingStartedAt > BIND_TIMEOUT_MS) {
                recoverStuckBinding();
            } else {
                return;
            }
        }
        try {
            binding = true;
            bindingStartedAt = SystemClock.elapsedRealtime();
            Shizuku.bindUserService(userServiceArgs, CONNECTION);
        } catch (Throwable t) {
            binding = false;
            bindingStartedAt = 0L;
            service = null;
            remoteUid = -1;
            // Do not poison direct-shell readiness with an optional backend error.
            lastError = "UserService: " + t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
        }
    }

    private static synchronized void recoverStuckBinding() {
        if (!initialized || userServiceArgs == null) return;
        try { Shizuku.unbindUserService(userServiceArgs, CONNECTION, true); } catch (Throwable ignored) {}
        service = null;
        remoteUid = -1;
        binding = false;
        bindingStartedAt = 0L;
        lastError = "UserService indisponível; usando shell direto quando possível";
    }

    public static synchronized void forceReconnect() {
        DirectShizukuShell.reset();
        if (!initialized || userServiceArgs == null || !hasPermission()) {
            notifyState();
            return;
        }
        try { Shizuku.unbindUserService(userServiceArgs, CONNECTION, true); } catch (Throwable ignored) {}
        service = null;
        remoteUid = -1;
        binding = false;
        bindingStartedAt = 0L;
        lastError = "";
        bindIfPossible();
        notifyState();
    }

    public static CommandResult exec(String command) {
        // Primary path: execute directly through Shizuku's shell process. This
        // works even on ROMs where app_process UserService never binds.
        CommandResult direct = DirectShizukuShell.exec(command);
        if (direct.exitCode != -991 && direct.exitCode != -990 && direct.exitCode != -989 &&
                direct.exitCode != -988 && direct.exitCode != -987) {
            return direct;
        }

        // Compatibility fallback: UserService, when available.
        IPrivilegedService s = service;
        if (s == null) {
            bindIfPossible();
            String detail = direct.output == null ? "" : direct.output;
            return new CommandResult(-994, "Shizuku autorizado, mas o shell ainda não respondeu" +
                    (detail.isEmpty() ? "" : " • " + detail));
        }
        try {
            int uid = s.uid();
            remoteUid = uid;
            if (uid != 0 && uid != 2000) {
                return new CommandResult(-992, "UserService sem privilégio shell/root. UID=" + uid);
            }
            return CommandResult.fromWire(s.exec(command));
        } catch (Throwable t) {
            service = null;
            remoteUid = -1;
            binding = false;
            bindingStartedAt = 0L;
            lastError = t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
            bindIfPossible();
            return new CommandResult(-993, lastError);
        }
    }

    public static String backendText() {
        if (DirectShizukuShell.available()) {
            int uid = DirectShizukuShell.uid();
            return "Shell direto Shizuku • UID " + uid;
        }
        if (service != null) return "UserService Shizuku • UID " + remoteUid;
        return "Nenhum backend privilegiado pronto";
    }

    public static String statusText() {
        if (!isBinderAlive()) return "Shizuku não está em execução";
        if (!hasPermission()) return "Shizuku ativo, aguardando autorização";
        if (DirectShizukuShell.available()) {
            int uid = DirectShizukuShell.uid();
            return "Pronto • shell direto UID " + uid + (uid == 2000 ? " (ADB)" : " (root)");
        }
        if (service != null) {
            int uid = remoteUid;
            return "Pronto • UserService UID " + uid + (uid == 2000 ? " (shell/ADB)" : " (root)");
        }
        String directError = DirectShizukuShell.lastError();
        String suffix = directError.isEmpty() ? "" : " • " + directError;
        return isBinding()
                ? "Autorizado • tentando backend privilegiado…" + suffix
                : "Autorizado • shell ainda não pronto" + suffix;
    }
}
