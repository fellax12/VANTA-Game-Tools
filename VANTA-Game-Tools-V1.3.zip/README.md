# VANTA Game Tools V1.3 alpha04

Compatibility-focused build for Android 15 / HyperOS.

Key changes:
- Shizuku direct remote-shell backend is now the primary privileged executor.
- UserService is optional fallback; a stuck UserService no longer blocks the app.
- Selected game remains the primary monitoring target.
- SurfaceFlinger TimeStats remains the primary FPS source.
- SurfaceFlinger per-layer latency is used as a secondary FPS fallback when available.
- Diagnostics now report the actual privileged backend and UID.

Expected Shizuku status on ADB/Wireless Debugging:
`Pronto • shell direto UID 2000 (ADB)`
