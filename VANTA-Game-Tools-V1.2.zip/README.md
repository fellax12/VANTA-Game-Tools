# VANTA Game Tools 1.2 alpha03

VANTA Game Tools é um toolkit Android para monitoramento e perfis de jogo usando Shizuku.

## V1.2 – correção da cadeia funcional

Esta versão foca no que falhou no primeiro teste real: jogo selecionado não virava alvo, foreground podia não ser detectado e o FPS ficava em `--`.

### Alterações principais

- O jogo selecionado pelo usuário agora é a fonte de verdade para o monitor.
- Detecção automática do app em primeiro plano virou confirmação/fallback, não requisito.
- ForegroundDetector usa vários sinais do WindowManager/ActivityManager para HyperOS/Android 15.
- O monitor verifica se o processo do jogo selecionado está realmente em execução com `pidof`.
- TimeStats do SurfaceFlinger é ativado automaticamente assim que o UserService Shizuku fica pronto, mesmo se a conexão atrasar.
- Recuperação automática caso TimeStats pare de gerar frames.
- Dump e clear são feitos em uma única chamada e o monitor pede até 120 camadas para reduzir falsos negativos.
- Parser de FPS procura a camada tanto pelo nome do pacote quanto pelo UID real do aplicativo.
- Prioridade para `SurfaceView`/`BLAST`, que normalmente representa a renderização principal do jogo.
- UserService Shizuku agora valida explicitamente UID 2000 (shell) ou 0 (root).
- AIDL usa o transaction code reservado correto do Shizuku para `destroy()`.
- UserService passou a daemon para maior estabilidade enquanto o monitor estiver ativo.
- Diagnóstico mostra UID do UserService, pacote selecionado, PID, foreground e trecho do SurfaceFlinger TimeStats.
- “Aplicar e abrir jogo” inicia o monitor flutuante automaticamente quando a permissão de overlay já existe.
- Mantidas as correções de layout/overlay da V1.1.

## Fluxo recomendado de teste

1. Inicie o Shizuku por Depuração sem fio.
2. Abra o VANTA e confirme que aparece `PRONTO • UserService UID 2000 (shell/ADB)`.
3. Conceda a permissão de sobreposição.
4. Selecione o jogo.
5. Salve o perfil.
6. Toque em “Iniciar monitor flutuante” ou use “Aplicar e abrir jogo”.
7. Abra o jogo selecionado.
8. A bolha deve sair de `V • -- FPS` para um valor real assim que a camada gráfica produzir amostras.
9. Se não houver FPS, abra “Diagnóstico VANTA” e confira UID, processo selecionado e TimeStats.

## Observação

Algumas intervenções de Game Mode, refresh rate e resolução podem ser bloqueadas ou ignoradas pelo fabricante/jogo. A telemetria de FPS é independente dessas intervenções e usa SurfaceFlinger TimeStats via shell/Shizuku.
