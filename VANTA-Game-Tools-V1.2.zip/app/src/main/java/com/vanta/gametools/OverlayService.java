package com.vanta.gametools;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class OverlayService extends Service {
    private static final String CHANNEL = "vanta_monitor";
    private static final int NOTIFICATION_ID = 7201;
    private static volatile boolean running;

    private WindowManager wm;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private View bubble;
    private View panel;
    private TextView bubbleText;
    private TextView panelTitle;
    private TextView panelPackage;
    private TextView panelFps;
    private TextView panelLow;
    private TextView panelFrame;
    private TextView panelHz;
    private TextView panelDrop;
    private TextView panelLayer;
    private FpsGraphView graph;
    private ScheduledExecutorService scheduler;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ProfileStore store;
    private GameTuner tuner;
    private volatile String currentPackage = "";
    private volatile String lastDetectedPackage = "";
    private volatile FpsSnapshot currentSnapshot = new FpsSnapshot();
    private volatile boolean timeStatsEnabled;
    private volatile boolean targetActive;
    private volatile String telemetryState = "Inicializando telemetria…";
    private int emptySamples;
    private String lastProfilePackage = "";

    public static boolean isRunning() { return running; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        PrivilegedBridge.init(this);
        PrivilegedBridge.bindIfPossible();
        store = new ProfileStore(this);
        tuner = new GameTuner(this);
        currentPackage = safe(store.getSelectedGamePackage());
        createNotificationChannel();
        startForegroundCompat();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        createBubble();
        startSampling();
    }

    private void startForegroundCompat() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_vanta)
                .setContentTitle("VANTA Game Tools")
                .setContentText("Monitor de desempenho ativo")
                .setOngoing(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "VANTA Monitor", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mantém o overlay e a telemetria de jogos ativos.");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void createBubble() {
        TextView tv = new TextView(this);
        tv.setText("V • -- FPS");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(11);
        tv.setGravity(Gravity.CENTER);
        tv.setSingleLine(true);
        tv.setPadding(dp(12), dp(7), dp(12), dp(7));
        tv.setTypeface(tv.getTypeface(), 1);
        tv.setBackground(rounded(Color.rgb(13, 15, 19), 16, Color.rgb(242, 106, 46)));
        bubble = tv;
        bubbleText = tv;

        bubbleParams = baseParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(12);
        bubbleParams.y = dp(92);
        wm.addView(bubble, bubbleParams);
        installDragAndTap();
    }

    private WindowManager.LayoutParams baseParams(int w, int h) {
        return new WindowManager.LayoutParams(
                w,
                h,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                android.graphics.PixelFormat.TRANSLUCENT
        );
    }

    private Rect screenBounds() {
        if (Build.VERSION.SDK_INT >= 30) {
            try { return new Rect(wm.getCurrentWindowMetrics().getBounds()); } catch (Throwable ignored) {}
        }
        DisplayMetrics dm = new DisplayMetrics();
        try { wm.getDefaultDisplay().getRealMetrics(dm); }
        catch (Throwable t) { dm.setTo(getResources().getDisplayMetrics()); }
        return new Rect(0, 0, Math.max(1, dm.widthPixels), Math.max(1, dm.heightPixels));
    }

    private boolean isLandscape() {
        Rect r = screenBounds();
        return r.width() > r.height();
    }

    private void installDragAndTap() {
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        Rect bounds = screenBounds();
                        int maxX = Math.max(0, bounds.width() - Math.max(dp(70), bubble.getWidth()));
                        int maxY = Math.max(0, bounds.height() - Math.max(dp(42), bubble.getHeight()));
                        bubbleParams.x = clamp(startX + Math.round(dx), 0, maxX);
                        bubbleParams.y = clamp(startY + Math.round(dy), 0, maxY);
                        try { wm.updateViewLayout(bubble, bubbleParams); } catch (Throwable ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                }
                return false;
            }
        });
    }

    private void togglePanel() {
        if (panel == null) showPanel(); else hidePanel();
    }

    private void showPanel() {
        Rect bounds = screenBounds();
        boolean landscape = bounds.width() > bounds.height();
        int margin = dp(10);
        int width = Math.min(landscape ? dp(270) : dp(330), Math.max(dp(220), bounds.width() - margin * 2));
        int desiredHeight = landscape ? dp(228) : dp(350);
        int height = Math.min(desiredHeight, Math.max(dp(190), bounds.height() - margin * 2));

        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setPadding(dp(12), dp(10), dp(12), dp(10));
        shell.setBackground(rounded(Color.rgb(15, 17, 22), 20, Color.rgb(48, 52, 62)));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        panelTitle = text("VANTA PERFORMANCE", 12, Color.rgb(242, 106, 46), true);
        panelTitle.setMaxLines(1);
        panelTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        panelPackage = text("Aguardando aplicativo…", 9, Color.rgb(156, 163, 175), false);
        panelPackage.setMaxLines(1);
        panelPackage.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        titleBox.addView(panelTitle);
        titleBox.addView(panelPackage, lp(-1, -2, 2, 0));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        Button minimize = iconButton("—");
        Button stop = iconButton("×");
        minimize.setContentDescription("Minimizar painel");
        stop.setContentDescription("Fechar monitor VANTA");
        minimize.setOnClickListener(v -> hidePanel());
        stop.setOnClickListener(v -> stopSelf());
        header.addView(minimize, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(dp(38), dp(38));
        stopLp.leftMargin = dp(6);
        header.addView(stop, stopLp);
        shell.addView(header, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, dp(6), 0, 0);

        LinearLayout metrics1 = new LinearLayout(this);
        metrics1.setOrientation(LinearLayout.HORIZONTAL);
        panelFps = metric(metrics1, "FPS", "--");
        panelLow = metric(metrics1, "1% LOW", "--");
        panelHz = metric(metrics1, "TELA", "--");
        body.addView(metrics1, lp(-1, -2, 0, landscape ? 2 : 6));

        LinearLayout metrics2 = new LinearLayout(this);
        metrics2.setOrientation(LinearLayout.HORIZONTAL);
        panelFrame = metric(metrics2, "FRAME", "--");
        panelDrop = metric(metrics2, "DROP", "--");
        body.addView(metrics2, lp(-1, -2, 0, 2));

        graph = new FpsGraphView(this);
        body.addView(graph, new LinearLayout.LayoutParams(-1, landscape ? dp(48) : dp(70)));

        panelLayer = text("Aguardando SurfaceFlinger…", 9, Color.rgb(120, 126, 138), false);
        panelLayer.setMaxLines(2);
        panelLayer.setEllipsize(android.text.TextUtils.TruncateAt.END);
        body.addView(panelLayer, lp(-1, -2, 4, 4));

        Button profile = smallButton("ABRIR PERFIL DO JOGO");
        profile.setOnClickListener(v -> openCurrentProfile());
        body.addView(profile, new LinearLayout.LayoutParams(-1, dp(40)));

        scroll.addView(body, new android.widget.FrameLayout.LayoutParams(-1, -2));
        shell.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        panel = shell;
        if (bubble != null) bubble.setVisibility(View.GONE);
        panelParams = baseParams(width, height);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = margin;
        panelParams.y = margin;
        wm.addView(panel, panelParams);
        updateOverlayUi();
    }

    private TextView metric(LinearLayout parent, String label, String initial) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(dp(3), dp(3), dp(3), dp(3));
        TextView l = text(label, 8, Color.rgb(135, 141, 153), true);
        TextView v = text(initial, isLandscape() ? 16 : 18, Color.WHITE, true);
        v.setSingleLine(true);
        cell.addView(l);
        cell.addView(v);
        parent.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
        return v;
    }

    private Button iconButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setPadding(0, 0, 0, dp(2));
        b.setBackground(rounded(Color.rgb(29, 32, 39), 12, Color.rgb(58, 62, 72)));
        return b;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(9);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setSingleLine(true);
        b.setMinHeight(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(rounded(Color.rgb(29, 32, 39), 12, Color.rgb(58, 62, 72)));
        return b;
    }

    private TextView text(String text, float sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(tv.getTypeface(), 1);
        return tv;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private void hidePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Throwable ignored) {}
            panel = null;
            graph = null;
            if (bubble != null) bubble.setVisibility(View.VISIBLE);
        }
    }

    private void openCurrentProfile() {
        String pkg = currentPackage;
        if (pkg == null || pkg.isEmpty() || pkg.equals(getPackageName())) {
            Toast.makeText(this, "Abra um jogo primeiro para o VANTA detectá-lo.", Toast.LENGTH_SHORT).show();
            return;
        }
        String label = pkg;
        try { label = String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0))); }
        catch (PackageManager.NameNotFoundException ignored) {}
        store.setSelectedGame(pkg, label);
        hidePanel();
        Intent i = new Intent(this, ProfileEditorActivity.class);
        i.putExtra("package", pkg);
        i.putExtra("label", label);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void startSampling() {
        scheduler = Executors.newSingleThreadScheduledExecutor();
        int interval = store.getSampleIntervalMs();
        scheduler.scheduleWithFixedDelay(this::sampleOnce, 250, interval, TimeUnit.MILLISECONDS);
    }

    private void sampleOnce() {
        try {
            if (!PrivilegedBridge.isReady()) {
                timeStatsEnabled = false;
                telemetryState = PrivilegedBridge.statusText();
                PrivilegedBridge.bindIfPossible();
                main.post(this::updateOverlayUi);
                return;
            }

            if (!timeStatsEnabled) {
                CommandResult enable = PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -clear -enable");
                if (!enable.ok()) {
                    telemetryState = "TimeStats não iniciou: " + compact(enable.output);
                    main.post(this::updateOverlayUi);
                    return;
                }
                timeStatsEnabled = true;
                emptySamples = 0;
                telemetryState = "TimeStats ativo • aguardando frames";
            }

            String detected = safe(ForegroundDetector.detectPackage());
            if (!detected.isEmpty() && !isIgnoredForeground(detected)) lastDetectedPackage = detected;

            String selected = safe(store.getSelectedGamePackage());
            boolean selectedRunning = !selected.isEmpty() && isPackageRunning(selected);
            String target;
            if (!selected.isEmpty()) {
                // O jogo escolhido pelo usuário é a fonte de verdade. Isso evita que
                // launchers, SystemUI ou variações do WindowManager quebrem o monitor.
                target = selected;
            } else if (!detected.isEmpty() && !isIgnoredForeground(detected)) {
                target = detected;
            } else {
                target = lastDetectedPackage;
            }

            boolean active = !target.isEmpty() && (target.equals(detected) || (target.equals(selected) && selectedRunning));
            if (!target.equals(currentPackage)) onTargetChanged(target);
            currentPackage = target;
            onTargetActivityChanged(target, active);

            if (currentPackage.isEmpty()) {
                telemetryState = "Selecione um jogo ou abra um app para monitorar";
                currentSnapshot = new FpsSnapshot();
                main.post(this::updateOverlayUi);
                return;
            }

            CommandResult dump = PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -dump -clear -maxlayers 120");
            if (!dump.ok()) {
                // Fallback para ROMs que alteram o suporte a -maxlayers.
                dump = PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -dump -clear");
            }
            if (!dump.ok()) {
                telemetryState = "SurfaceFlinger indisponível: " + compact(dump.output);
                main.post(this::updateOverlayUi);
                return;
            }

            int uid = packageUid(currentPackage);
            FpsSnapshot parsed = FpsParser.parse(dump.output, currentPackage, uid);
            currentSnapshot = parsed;
            if (parsed.hasData()) {
                emptySamples = 0;
                telemetryState = "FPS real • SurfaceFlinger TimeStats";
            } else {
                emptySamples++;
                if (active) {
                    telemetryState = "Jogo detectado • aguardando camada gráfica";
                } else {
                    telemetryState = "Jogo selecionado • aguardando abertura/frames";
                }
                // Se o serviço conectou depois do monitor iniciar ou o OEM limpou
                // TimeStats, uma reativação periódica recupera a captura sozinha.
                if (emptySamples >= 5) {
                    PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -enable");
                    emptySamples = 0;
                }
            }
            main.post(this::updateOverlayUi);
        } catch (Throwable t) {
            telemetryState = "Telemetria: " + t.getClass().getSimpleName();
            main.post(this::updateOverlayUi);
        }
    }

    private boolean isPackageRunning(String pkg) {
        if (pkg == null || pkg.isEmpty()) return false;
        CommandResult r = PrivilegedBridge.exec("pidof " + shellQuote(pkg));
        return r.ok() && r.output != null && !r.output.trim().isEmpty();
    }

    private int packageUid(String pkg) {
        if (pkg == null || pkg.isEmpty()) return -1;
        try { return getPackageManager().getApplicationInfo(pkg, 0).uid; }
        catch (Throwable ignored) { return -1; }
    }

    private boolean isIgnoredForeground(String pkg) {
        if (pkg == null || pkg.isEmpty()) return true;
        if (pkg.equals(getPackageName())) return true;
        return pkg.equals("com.android.systemui") ||
                pkg.equals("android") ||
                pkg.contains("permissioncontroller");
    }

    private void onTargetChanged(String pkg) {
        if (!lastProfilePackage.isEmpty() && !pkg.equals(lastProfilePackage)) {
            tuner.restoreRefreshRate();
            lastProfilePackage = "";
        }
        targetActive = false;
        currentSnapshot = new FpsSnapshot();
        main.post(() -> { if (graph != null) graph.clear(); });
    }

    private void onTargetActivityChanged(String pkg, boolean active) {
        if (active == targetActive) return;
        targetActive = active;
        if (active && pkg != null && !pkg.isEmpty() && !pkg.equals(getPackageName())) {
            GameProfile p = store.getProfile(pkg);
            if (store.hasProfile(pkg) && p.enabled && p.autoApply) {
                lastProfilePackage = pkg;
                tuner.applyProfile(pkg, p, true);
            }
        } else if (!active && !lastProfilePackage.isEmpty()) {
            tuner.restoreRefreshRate();
            lastProfilePackage = "";
        }
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private static String compact(String value) {
        if (value == null) return "sem resposta";
        String v = value.replace('\n', ' ').replace('\r', ' ').trim();
        return v.length() > 90 ? v.substring(0, 90) + "…" : v;
    }

    private static String shellQuote(String value) {
        if (value == null) return "''";
        return "'" + value.replace("'", "'\"'\"'") + "'";
    }

    private void updateOverlayUi() {
        if (bubbleText == null) return;
        FpsSnapshot s = currentSnapshot;
        int displayHz = s.displayRefreshRate > 0 ? s.displayRefreshRate : currentDisplayHz();
        String fps = s.hasData() ? String.format(Locale.US, "%.0f", s.fps) : "--";
        bubbleText.setText(PrivilegedBridge.isReady() ? "V • " + fps + " FPS" : "V • SHZ");
        if (panel == null) return;

        String label = currentPackage;
        if (currentPackage != null && !currentPackage.isEmpty()) {
            try { label = String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(currentPackage, 0))); }
            catch (Throwable ignored) {}
        }
        if (!PrivilegedBridge.isReady()) {
            panelTitle.setText("VANTA PERFORMANCE");
            panelPackage.setText(PrivilegedBridge.hasPermission() ? "Shizuku autorizado • conectando shell…" : "Shizuku não autorizado");
        } else {
            panelTitle.setText(label == null || label.isEmpty() ? "VANTA PERFORMANCE" : label);
            panelPackage.setText(currentPackage == null || currentPackage.isEmpty() ? "Aguardando jogo em primeiro plano…" : currentPackage);
        }
        panelFps.setText(s.hasData() ? String.format(Locale.US, "%.1f", s.fps) : "--");
        panelLow.setText(s.onePercentLow > 0 ? String.format(Locale.US, "%.0f", s.onePercentLow) : "--");
        panelFrame.setText(s.frameTimeMs > 0 ? String.format(Locale.US, "%.1f ms", s.frameTimeMs) : "--");
        panelHz.setText(displayHz > 0 ? displayHz + " Hz" : "--");
        panelDrop.setText(s.totalFrames > 0 ? String.format(Locale.US, "%.1f%%", s.droppedPercent()) : "--");
        if (s.layerName == null || s.layerName.isEmpty()) {
            panelLayer.setText(telemetryState);
        } else {
            panelLayer.setText(telemetryState + "\nLayer: " + s.layerName);
        }
        if (graph != null && s.hasData()) graph.addValue((float) s.fps);
    }

    private int currentDisplayHz() {
        try {
            if (getDisplay() != null) return Math.round(getDisplay().getRefreshRate());
        } catch (Throwable ignored) {}
        return 0;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (scheduler != null) scheduler.shutdownNow();
        try {
            if (PrivilegedBridge.isReady()) PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -disable");
        } catch (Throwable ignored) {}
        try { tuner.restoreRefreshRate(); } catch (Throwable ignored) {}
        hidePanel();
        if (bubble != null) {
            try { wm.removeView(bubble); } catch (Throwable ignored) {}
            bubble = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
}
