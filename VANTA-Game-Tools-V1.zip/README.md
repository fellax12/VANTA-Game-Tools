# VANTA Game Tools — V1 alpha

Android 11+ utility focused on game telemetry and per-game tuning using Shizuku (ADB/root identity).

## What is implemented

- Floating draggable FPS overlay.
- Expanded in-game performance panel.
- SurfaceFlinger TimeStats sampling for real per-layer FPS.
- Frame time, approximate 1% low, display refresh rate, dropped-frame percentage and FPS history graph.
- Automatic foreground package detection using WindowManager/ActivityManager shell state.
- Per-app profiles.
- Android Game Mode: standard / performance / battery.
- Android Game Mode FPS intervention: 30 / 45 / 60 / 90 FPS (this is a cap/intervention; it does not magically unlock a game that is internally limited).
- Preferred 60/90 Hz system setting with backup and restoration.
- Experimental Android inverse-downscaling compatibility overrides from 1.11× through 2.00×.
- Backup/restoration of the original `game_overlay` DeviceConfig before VANTA overwrites it.
- Diagnostics screen for Shizuku, foreground detection, SurfaceFlinger and Game Service.

## Important behavior

The inverse-downscaling feature is intentionally marked experimental. Public Android user builds normally restrict compatibility overrides for non-debuggable third-party apps. VANTA executes the real framework command and shows the command result instead of claiming an upscale was applied when the device rejected it.

Game Mode interventions are OEM/game dependent. Some titles opt out or implement their own Game Mode behavior.

## Build

This source archive is designed to be built by the companion `build.yml` workflow supplied separately. The workflow installs Java 17, Android SDK 35 and Gradle 8.9, extracts this ZIP, runs `:app:assembleDebug`, and uploads a signed debug APK as a GitHub Actions artifact.

## Device target used for this V1

Primary test target: Android 15 / API 35, Xiaomi/Redmi device with Shizuku started through Wireless Debugging.
