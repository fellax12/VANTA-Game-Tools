package com.vanta.gametools;

interface IPrivilegedService {
    String exec(String command);
    int uid();
    void destroy();
}
