package com.vanta.gametools;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class FpsParser {
    private static final Pattern HIST = Pattern.compile("(\\d+)ms=(\\d+)");

    private FpsParser() {}

    private static final class Candidate {
        String layerName = "";
        String packageName = "";
        double fps;
        int displayRefreshRate;
        long totalFrames;
        long droppedFrames;
        String histogram = "";
    }

    public static FpsSnapshot parse(String output, String targetPackage) {
        FpsSnapshot empty = new FpsSnapshot();
        empty.packageName = targetPackage == null ? "" : targetPackage;
        if (output == null || output.isEmpty() || targetPackage == null || targetPackage.isEmpty()) return empty;

        List<Candidate> candidates = new ArrayList<>();
        Candidate c = null;
        String[] lines = output.split("\\r?\\n");
        boolean nextHistogram = false;
        for (String raw : lines) {
            String line = raw.trim();
            if (line.startsWith("layerName =")) {
                if (c != null) candidates.add(c);
                c = new Candidate();
                c.layerName = value(line);
                nextHistogram = false;
                continue;
            }
            if (c == null) continue;
            if (line.startsWith("packageName =")) c.packageName = value(line);
            else if (line.startsWith("averageFPS =")) c.fps = parseDouble(value(line));
            else if (line.startsWith("displayRefreshRate =")) c.displayRefreshRate = (int) parseDouble(value(line).replace("fps", "").trim());
            else if (line.startsWith("totalFrames =")) c.totalFrames = parseLong(value(line));
            else if (line.startsWith("droppedFrames =")) c.droppedFrames = parseLong(value(line));
            else if (line.toLowerCase(Locale.ROOT).startsWith("present2present histogram")) nextHistogram = true;
            else if (nextHistogram && line.contains("ms=")) {
                c.histogram = line;
                nextHistogram = false;
            }
        }
        if (c != null) candidates.add(c);

        Candidate best = null;
        String target = targetPackage.toLowerCase(Locale.ROOT);
        for (Candidate x : candidates) {
            String layer = x.layerName == null ? "" : x.layerName.toLowerCase(Locale.ROOT);
            String pkg = x.packageName == null ? "" : x.packageName.toLowerCase(Locale.ROOT);
            boolean match = pkg.equals(target) || pkg.contains(target) || layer.contains(target);
            if (!match) continue;
            if (best == null || score(x) > score(best)) best = x;
        }
        if (best == null) return empty;

        FpsSnapshot s = new FpsSnapshot();
        s.packageName = targetPackage;
        s.layerName = best.layerName;
        s.fps = best.fps;
        s.frameTimeMs = best.fps > 0 ? 1000.0 / best.fps : 0;
        s.displayRefreshRate = best.displayRefreshRate;
        s.totalFrames = best.totalFrames;
        s.droppedFrames = best.droppedFrames;
        s.onePercentLow = onePercentLow(best.histogram);
        if (s.onePercentLow <= 0 && s.fps > 0) s.onePercentLow = s.fps;
        return s;
    }

    private static long score(Candidate c) {
        long score = c.totalFrames;
        String name = c.layerName == null ? "" : c.layerName.toLowerCase(Locale.ROOT);
        if (name.contains("surfaceview")) score += 5_000_000L;
        if (name.contains("blast")) score += 2_000_000L;
        if (c.fps > 0) score += 1_000_000L;
        return score;
    }

    private static String value(String line) {
        int idx = line.indexOf('=');
        return idx >= 0 ? line.substring(idx + 1).trim() : "";
    }

    private static double parseDouble(String s) {
        try { return Double.parseDouble(s.trim()); } catch (Throwable t) { return 0; }
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Throwable t) { return 0; }
    }

    private static double onePercentLow(String histogram) {
        if (histogram == null || histogram.isEmpty()) return 0;
        Matcher m = HIST.matcher(histogram);
        List<int[]> buckets = new ArrayList<>();
        long total = 0;
        while (m.find()) {
            int ms = Integer.parseInt(m.group(1));
            int count = Integer.parseInt(m.group(2));
            if (count > 0) {
                buckets.add(new int[]{ms, count});
                total += count;
            }
        }
        if (total == 0) return 0;
        long target = (long) Math.ceil(total * 0.99);
        long acc = 0;
        int percentileMs = 0;
        for (int[] b : buckets) {
            acc += b[1];
            if (acc >= target) {
                percentileMs = b[0];
                break;
            }
        }
        return percentileMs > 0 ? 1000.0 / percentileMs : 0;
    }
}
