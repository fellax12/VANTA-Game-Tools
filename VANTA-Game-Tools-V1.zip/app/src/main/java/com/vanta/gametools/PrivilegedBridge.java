package com.vanta.gametools;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;

import java.util.concurrent.CopyOnWriteArrayList;

import rikka.shizuku.Shizuku;

public final class PrivilegedBridge {
    public interface StateListener { void onStateChanged(); }

    public static final int REQUEST_CODE = 4901;
    private static volatile boolean initialized;
    private static volatile boolean binding;
    private static volatile IPrivilegedService service;
    private static Context appContext;
    private static Shizuku.UserServiceArgs userServiceArgs;
    private static final CopyOnWriteArrayList<StateListener> listeners = new CopyOnWriteArrayList<>();

    private PrivilegedBridge() {}

    private static final Shizuku.OnBinderReceivedListener BINDER_RECEIVED = () -> {
        binding = false;
        bindIfPossible();
        notifyState();
    };

    private static final Shizuku.OnBinderDeadListener BINDER_DEAD = () -> {
        service = null;
        binding = false;
        notifyState();
    };

    private static final Shizuku.OnRequestPermissionResultListener PERMISSION_RESULT = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE && grantResult == PackageManager.PERMISSION_GRANTED) {
            bindIfPossible();
        }
        notifyState();
    };

    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IPrivilegedService.Stub.asInterface(binder);
            binding = false;
            notifyState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
            binding = false;
            notifyState();
        }
    };

    public static synchronized void init(Context context) {
        if (initialized) return;
        appContext = context.getApplicationContext();
        userServiceArgs = new Shizuku.UserServiceArgs(new ComponentName(appContext, PrivilegedService.class))
                .daemon(false)
                .processNameSuffix("vanta_shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE);
        Shizuku.addBinderReceivedListenerSticky(BINDER_RECEIVED);
        Shizuku.addBinderDeadListener(BINDER_DEAD);
        Shizuku.addRequestPermissionResultListener(PERMISSION_RESULT);
        initialized = true;
        bindIfPossible();
    }

    public static void addStateListener(StateListener listener) {
        if (listener != null) listeners.addIfAbsent(listener);
    }

    public static void removeStateListener(StateListener listener) {
        listeners.remove(listener);
    }

    private static void notifyState() {
        for (StateListener listener : listeners) {
            try { listener.onStateChanged(); } catch (Throwable ignored) {}
        }
    }

    public static boolean isBinderAlive() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    public static boolean hasPermission() {
        if (!isBinderAlive()) return false;
        try { return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    public static boolean isReady() {
        return hasPermission() && service != null;
    }

    public static boolean isBinding() {
        return binding;
    }

    public static int shizukuUid() {
        if (!isBinderAlive()) return -1;
        try { return Shizuku.getUid(); } catch (Throwable t) { return -1; }
    }

    public static void requestPermission() {
        if (!isBinderAlive()) return;
        if (hasPermission()) {
            bindIfPossible();
            return;
        }
        try { Shizuku.requestPermission(REQUEST_CODE); } catch (Throwable ignored) {}
    }

    public static synchronized void bindIfPossible() {
        if (!initialized || service != null || binding || !hasPermission()) return;
        try {
            binding = true;
            Shizuku.bindUserService(userServiceArgs, CONNECTION);
        } catch (Throwable t) {
            binding = false;
            service = null;
        }
    }

    public static CommandResult exec(String command) {
        IPrivilegedService s = service;
        if (s == null) {
            bindIfPossible();
            return new CommandResult(-994, isBinderAlive() ? "Shizuku autorizado, serviço privilegiado ainda conectando" : "Shizuku indisponível");
        }
        try {
            return CommandResult.fromWire(s.exec(command));
        } catch (Throwable t) {
            service = null;
            binding = false;
            return new CommandResult(-993, t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        }
    }

    public static String statusText() {
        if (!isBinderAlive()) return "Shizuku não está em execução";
        if (!hasPermission()) return "Shizuku ativo, aguardando autorização";
        if (service == null) return binding ? "Autorizado, conectando serviço shell…" : "Autorizado, serviço shell ainda não conectado";
        int uid = shizukuUid();
        return "Pronto • UID " + uid + (uid == 2000 ? " (ADB)" : uid == 0 ? " (root)" : "");
    }
}
