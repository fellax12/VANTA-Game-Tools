package com.vanta.gametools;

import android.content.Context;
import android.content.SharedPreferences;

public class ProfileStore {
    private static final String PREFS = "vanta_game_tools";
    private final SharedPreferences prefs;

    public ProfileStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private String profileKey(String pkg) { return "profile." + pkg; }
    private String overlayBackupKey(String pkg) { return "backup.overlay." + pkg; }

    public boolean hasProfile(String pkg) {
        return prefs.contains(profileKey(pkg));
    }

    public GameProfile getProfile(String pkg) {
        return GameProfile.decode(prefs.getString(profileKey(pkg), null));
    }

    public void saveProfile(String pkg, GameProfile profile) {
        prefs.edit().putString(profileKey(pkg), profile.encode()).apply();
    }

    public void deleteProfile(String pkg) {
        prefs.edit().remove(profileKey(pkg)).apply();
    }

    public int getSampleIntervalMs() {
        return prefs.getInt("sample_interval_ms", 1000);
    }

    public void setSampleIntervalMs(int ms) {
        prefs.edit().putInt("sample_interval_ms", Math.max(500, Math.min(ms, 2000))).apply();
    }

    public boolean hasOverlayBackup(String pkg) {
        return prefs.contains(overlayBackupKey(pkg));
    }

    public void saveOverlayBackup(String pkg, String value) {
        prefs.edit().putString(overlayBackupKey(pkg), value == null ? "__NULL__" : value).apply();
    }

    public String getOverlayBackup(String pkg) {
        return prefs.getString(overlayBackupKey(pkg), null);
    }

    public void clearOverlayBackup(String pkg) {
        prefs.edit().remove(overlayBackupKey(pkg)).apply();
    }

    public boolean hasRefreshBackup() {
        return prefs.getBoolean("refresh_backup_set", false);
    }

    public void saveRefreshBackup(String min, String peak) {
        prefs.edit()
                .putBoolean("refresh_backup_set", true)
                .putString("refresh_min", min == null ? "__NULL__" : min)
                .putString("refresh_peak", peak == null ? "__NULL__" : peak)
                .apply();
    }

    public String getRefreshMinBackup() { return prefs.getString("refresh_min", "__NULL__"); }
    public String getRefreshPeakBackup() { return prefs.getString("refresh_peak", "__NULL__"); }

    public void clearRefreshBackup() {
        prefs.edit().remove("refresh_backup_set").remove("refresh_min").remove("refresh_peak").apply();
    }
}
