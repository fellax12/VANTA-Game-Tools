package com.vanta.gametools;

import android.graphics.drawable.Drawable;

public class AppItem {
    public final String label;
    public final String packageName;
    public final Drawable icon;
    public final boolean hasProfile;

    public AppItem(String label, String packageName, Drawable icon, boolean hasProfile) {
        this.label = label;
        this.packageName = packageName;
        this.icon = icon;
        this.hasProfile = hasProfile;
    }
}
