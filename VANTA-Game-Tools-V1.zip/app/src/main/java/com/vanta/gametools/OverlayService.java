package com.vanta.gametools;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class OverlayService extends Service {
    private static final String CHANNEL = "vanta_monitor";
    private static final int NOTIFICATION_ID = 7201;
    private static volatile boolean running;

    private WindowManager wm;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private View bubble;
    private View panel;
    private TextView bubbleText;
    private TextView panelTitle;
    private TextView panelPackage;
    private TextView panelFps;
    private TextView panelLow;
    private TextView panelFrame;
    private TextView panelHz;
    private TextView panelDrop;
    private TextView panelLayer;
    private FpsGraphView graph;
    private ScheduledExecutorService scheduler;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ProfileStore store;
    private GameTuner tuner;
    private volatile String currentPackage = "";
    private volatile FpsSnapshot currentSnapshot = new FpsSnapshot();
    private String lastProfilePackage = "";

    public static boolean isRunning() { return running; }

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        PrivilegedBridge.init(this);
        PrivilegedBridge.bindIfPossible();
        store = new ProfileStore(this);
        tuner = new GameTuner(this);
        createNotificationChannel();
        startForegroundCompat();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        createBubble();
        startSampling();
    }

    private void startForegroundCompat() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_vanta)
                .setContentTitle("VANTA Game Tools")
                .setContentText("Monitor de desempenho ativo")
                .setOngoing(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "VANTA Monitor", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Mantém o overlay e a telemetria de jogos ativos.");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    private void createBubble() {
        TextView tv = new TextView(this);
        tv.setText("V • -- FPS");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(12);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(13), dp(8), dp(13), dp(8));
        tv.setTypeface(tv.getTypeface(), 1);
        GradientDrawable bg = rounded(Color.rgb(13, 15, 19), 18, Color.rgb(242, 106, 46));
        tv.setBackground(bg);
        bubble = tv;
        bubbleText = tv;

        bubbleParams = baseParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(16);
        bubbleParams.y = dp(160);
        wm.addView(bubble, bubbleParams);
        installDragAndTap();
    }

    private WindowManager.LayoutParams baseParams(int w, int h) {
        return new WindowManager.LayoutParams(
                w,
                h,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
        );
    }

    private void installDragAndTap() {
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX();
                        downY = event.getRawY();
                        startX = bubbleParams.x;
                        startY = bubbleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downX;
                        float dy = event.getRawY() - downY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) moved = true;
                        bubbleParams.x = Math.max(0, startX + Math.round(dx));
                        bubbleParams.y = Math.max(0, startY + Math.round(dy));
                        try { wm.updateViewLayout(bubble, bubbleParams); } catch (Throwable ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                }
                return false;
            }
        });
    }

    private void togglePanel() {
        if (panel == null) showPanel(); else hidePanel();
    }

    private void showPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(16));
        root.setBackground(rounded(Color.rgb(15, 17, 22), 22, Color.rgb(48, 52, 62)));

        panelTitle = text("VANTA PERFORMANCE", 13, Color.rgb(242, 106, 46), true);
        panelPackage = text("—", 12, Color.rgb(156, 163, 175), false);
        root.addView(panelTitle);
        root.addView(panelPackage, lp(-1, -2, 0, 3));

        LinearLayout metrics1 = new LinearLayout(this);
        metrics1.setOrientation(LinearLayout.HORIZONTAL);
        panelFps = metric(metrics1, "FPS", "--");
        panelLow = metric(metrics1, "1% LOW", "--");
        panelHz = metric(metrics1, "TELA", "--");
        root.addView(metrics1, lp(-1, -2, 0, 14));

        LinearLayout metrics2 = new LinearLayout(this);
        metrics2.setOrientation(LinearLayout.HORIZONTAL);
        panelFrame = metric(metrics2, "FRAME", "--");
        panelDrop = metric(metrics2, "DROP", "--");
        root.addView(metrics2, lp(-1, -2, 0, 8));

        graph = new FpsGraphView(this);
        root.addView(graph, new LinearLayout.LayoutParams(-1, dp(92)));

        panelLayer = text("Aguardando SurfaceFlinger…", 10, Color.rgb(120, 126, 138), false);
        root.addView(panelLayer, lp(-1, -2, 0, 8));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button profile = smallButton("AJUSTAR JOGO");
        Button close = smallButton("MINIMIZAR");
        Button stop = smallButton("PARAR");
        profile.setOnClickListener(v -> openCurrentProfile());
        close.setOnClickListener(v -> hidePanel());
        stop.setOnClickListener(v -> stopSelf());
        actions.addView(profile, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(close, new LinearLayout.LayoutParams(0, dp(46), 1));
        actions.addView(stop, new LinearLayout.LayoutParams(0, dp(46), 1));
        root.addView(actions, lp(-1, -2, 0, 12));

        panel = root;
        panelParams = baseParams(dp(330), WindowManager.LayoutParams.WRAP_CONTENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(14);
        panelParams.y = Math.max(dp(70), bubbleParams.y + dp(48));
        wm.addView(panel, panelParams);
        updateOverlayUi();
    }

    private TextView metric(LinearLayout parent, String label, String initial) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(dp(4), dp(6), dp(4), dp(6));
        TextView l = text(label, 9, Color.rgb(135, 141, 153), true);
        TextView v = text(initial, 20, Color.WHITE, true);
        cell.addView(l);
        cell.addView(v);
        parent.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
        return v;
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(9);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setBackground(rounded(Color.rgb(29, 32, 39), 12, Color.rgb(58, 62, 72)));
        return b;
    }

    private TextView text(String text, float sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(tv.getTypeface(), 1);
        return tv;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private GradientDrawable rounded(int fill, int radiusDp, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private void hidePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Throwable ignored) {}
            panel = null;
            graph = null;
        }
    }

    private void openCurrentProfile() {
        String pkg = currentPackage;
        if (pkg == null || pkg.isEmpty() || pkg.equals(getPackageName())) return;
        String label = pkg;
        try { label = String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0))); }
        catch (PackageManager.NameNotFoundException ignored) {}
        hidePanel();
        Intent i = new Intent(this, ProfileEditorActivity.class);
        i.putExtra("package", pkg);
        i.putExtra("label", label);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    private void startSampling() {
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.execute(() -> {
            for (int i = 0; i < 12 && !PrivilegedBridge.isReady(); i++) {
                PrivilegedBridge.bindIfPossible();
                try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
            }
            if (PrivilegedBridge.isReady()) {
                PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -clear -enable");
            }
        });
        int interval = store.getSampleIntervalMs();
        scheduler.scheduleWithFixedDelay(this::sampleOnce, 800, interval, TimeUnit.MILLISECONDS);
    }

    private void sampleOnce() {
        try {
            if (!PrivilegedBridge.isReady()) {
                PrivilegedBridge.bindIfPossible();
                main.post(this::updateOverlayUi);
                return;
            }

            String detected = ForegroundDetector.detectPackage();
            if (detected != null && !detected.isEmpty()) {
                if (!detected.equals(currentPackage)) onForegroundChanged(detected);
                currentPackage = detected;
            }

            if (!currentPackage.isEmpty()) {
                CommandResult dump = PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -dump");
                if (dump.ok()) currentSnapshot = FpsParser.parse(dump.output, currentPackage);
                PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -clear");
            }
            main.post(this::updateOverlayUi);
        } catch (Throwable ignored) {}
    }

    private void onForegroundChanged(String pkg) {
        if (!lastProfilePackage.isEmpty() && !pkg.equals(lastProfilePackage)) {
            tuner.restoreRefreshRate();
            lastProfilePackage = "";
        }
        if (!pkg.equals(getPackageName())) {
            GameProfile p = store.getProfile(pkg);
            if (store.hasProfile(pkg) && p.enabled && p.autoApply) {
                lastProfilePackage = pkg;
                tuner.applyProfile(pkg, p, true);
            }
        }
        currentSnapshot = new FpsSnapshot();
        main.post(() -> { if (graph != null) graph.clear(); });
    }

    private void updateOverlayUi() {
        if (bubbleText == null) return;
        FpsSnapshot s = currentSnapshot;
        int displayHz = s.displayRefreshRate > 0 ? s.displayRefreshRate : currentDisplayHz();
        String fps = s.hasData() ? String.format(Locale.US, "%.0f", s.fps) : "--";
        bubbleText.setText("V • " + fps + " FPS");
        if (panel == null) return;

        String label = currentPackage;
        if (currentPackage != null && !currentPackage.isEmpty()) {
            try { label = String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(currentPackage, 0))); }
            catch (Throwable ignored) {}
        }
        panelTitle.setText(label == null || label.isEmpty() ? "VANTA PERFORMANCE" : label);
        panelPackage.setText(currentPackage == null || currentPackage.isEmpty() ? "Aguardando aplicativo…" : currentPackage);
        panelFps.setText(s.hasData() ? String.format(Locale.US, "%.1f", s.fps) : "--");
        panelLow.setText(s.onePercentLow > 0 ? String.format(Locale.US, "%.0f", s.onePercentLow) : "--");
        panelFrame.setText(s.frameTimeMs > 0 ? String.format(Locale.US, "%.1f ms", s.frameTimeMs) : "--");
        panelHz.setText(displayHz > 0 ? displayHz + " Hz" : "--");
        panelDrop.setText(s.totalFrames > 0 ? String.format(Locale.US, "%.1f%%", s.droppedPercent()) : "--");
        panelLayer.setText(s.layerName == null || s.layerName.isEmpty() ? "SurfaceFlinger: sem camada correspondente nesta amostra" : "Layer: " + s.layerName);
        if (graph != null && s.hasData()) graph.addValue((float) s.fps);
    }

    private int currentDisplayHz() {
        try {
            if (getDisplay() != null) return Math.round(getDisplay().getRefreshRate());
        } catch (Throwable ignored) {}
        return 0;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (scheduler != null) scheduler.shutdownNow();
        try { PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -disable"); } catch (Throwable ignored) {}
        try { tuner.restoreRefreshRate(); } catch (Throwable ignored) {}
        hidePanel();
        if (bubble != null) {
            try { wm.removeView(bubble); } catch (Throwable ignored) {}
            bubble = null;
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
}
