package com.vanta.gametools;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Display;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.Arrays;
import java.util.Locale;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextView shizukuStatus;
    private TextView shizukuDetail;
    private TextView overlayStatus;
    private TextView monitorStatus;
    private TextView monitorDetail;
    private TextView deviceInfo;
    private MaterialButton startButton;
    private MaterialAutoCompleteTextView sampleInterval;

    private final PrivilegedBridge.StateListener bridgeListener = () -> runOnUiThread(this::refreshStatus);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UiInsets.applySystemBars(findViewById(R.id.contentRoot));
        PrivilegedBridge.init(this);
        PrivilegedBridge.addStateListener(bridgeListener);

        shizukuStatus = findViewById(R.id.shizukuStatus);
        shizukuDetail = findViewById(R.id.shizukuDetail);
        overlayStatus = findViewById(R.id.overlayStatus);
        monitorStatus = findViewById(R.id.monitorStatus);
        monitorDetail = findViewById(R.id.monitorDetail);
        deviceInfo = findViewById(R.id.deviceInfo);
        startButton = findViewById(R.id.startButton);
        sampleInterval = findViewById(R.id.sampleInterval);

        findViewById(R.id.shizukuButton).setOnClickListener(v -> {
            if (!PrivilegedBridge.isBinderAlive()) {
                Toast.makeText(this, "Abra o Shizuku e inicie o serviço por Depuração sem fio.", Toast.LENGTH_LONG).show();
                Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch != null) startActivity(launch);
            } else {
                PrivilegedBridge.requestPermission();
            }
        });
        findViewById(R.id.overlayButton).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.profilesButton).setOnClickListener(v -> startActivity(new Intent(this, ProfilesActivity.class)));
        findViewById(R.id.diagnosticsButton).setOnClickListener(v -> runDiagnostics());
        startButton.setOnClickListener(v -> toggleMonitor());

        setupSampleInterval();
        updateDeviceInfo();
        requestNotificationsIfNeeded();
        refreshStatus();
    }

    private void setupSampleInterval() {
        String[] labels = {"0,5 s • mais responsivo", "1,0 s • recomendado", "1,5 s • econômico", "2,0 s • mínimo impacto"};
        int[] values = {500, 1000, 1500, 2000};
        sampleInterval.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, labels));
        int current = new ProfileStore(this).getSampleIntervalMs();
        int idx = 1;
        for (int i = 0; i < values.length; i++) if (values[i] == current) idx = i;
        sampleInterval.setText(labels[idx], false);
        sampleInterval.setOnItemClickListener((parent, view, position, id) -> new ProfileStore(this).setSampleIntervalMs(values[position]));
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 8801);
        }
    }

    private void requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Sobreposição já autorizada", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void toggleMonitor() {
        if (OverlayService.isRunning()) {
            stopService(new Intent(this, OverlayService.class));
            getWindow().getDecorView().postDelayed(this::refreshStatus, 350);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            requestOverlay();
            return;
        }
        if (!PrivilegedBridge.hasPermission()) {
            PrivilegedBridge.requestPermission();
            Toast.makeText(this, "Autorize o Shizuku antes de iniciar.", Toast.LENGTH_LONG).show();
            return;
        }
        PrivilegedBridge.bindIfPossible();
        ContextCompat.startForegroundService(this, new Intent(this, OverlayService.class));
        getWindow().getDecorView().postDelayed(this::refreshStatus, 500);
    }

    private void refreshStatus() {
        boolean binder = PrivilegedBridge.isBinderAlive();
        boolean permission = PrivilegedBridge.hasPermission();
        boolean ready = PrivilegedBridge.isReady();
        if (ready) {
            setChip(shizukuStatus, "PRONTO", true, false);
        } else if (binder && permission) {
            setChip(shizukuStatus, "CONECTANDO", false, false);
        } else if (binder) {
            setChip(shizukuStatus, "AUTORIZAR", false, false);
        } else {
            setChip(shizukuStatus, "OFF", false, true);
        }
        shizukuDetail.setText(PrivilegedBridge.statusText());

        boolean overlay = Settings.canDrawOverlays(this);
        setChip(overlayStatus, overlay ? "PERMITIDO" : "BLOQUEADO", overlay, !overlay);

        boolean running = OverlayService.isRunning();
        setChip(monitorStatus, running ? "ATIVO" : "OFF", running, false);
        monitorDetail.setText(running ? "Overlay e telemetria em execução" : "Parado");
        startButton.setText(running ? "PARAR MONITOR FLUTUANTE" : "INICIAR MONITOR FLUTUANTE");
    }

    private void setChip(TextView view, String text, boolean ok, boolean bad) {
        view.setText(text);
        view.setBackgroundResource(ok ? R.drawable.bg_status_ok : bad ? R.drawable.bg_status_bad : R.drawable.bg_status_warn);
    }

    private void updateDeviceInfo() {
        Display display = getDisplay();
        TreeSet<Integer> rates = new TreeSet<>();
        if (display != null) {
            for (Display.Mode m : display.getSupportedModes()) rates.add(Math.round(m.getRefreshRate()));
        }
        String text = Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android " + Build.VERSION.RELEASE + " • API " + Build.VERSION.SDK_INT + "\n" +
                "Taxas reportadas pela tela: " + Arrays.toString(rates.toArray()) + " Hz\n" +
                "VANTA " + BuildConfig.VERSION_NAME;
        deviceInfo.setText(text);
    }

    private void runDiagnostics() {
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico VANTA")
                .setMessage("Executando testes de Shizuku, foreground app, SurfaceFlinger e Game Service…")
                .setPositiveButton("OK", null)
                .show();
        io.execute(() -> {
            StringBuilder out = new StringBuilder();
            out.append("VANTA DIAGNOSTICS\n\n");
            out.append("Shizuku: ").append(PrivilegedBridge.statusText()).append('\n');
            CommandResult uid = PrivilegedBridge.exec("id");
            out.append("\n[id]\n").append(uid).append('\n');
            CommandResult focus = PrivilegedBridge.exec("dumpsys window windows | grep -m 1 'mCurrentFocus'");
            out.append("\n[foreground]\n").append(focus).append('\n');
            CommandResult sf = PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -dump | head -n 35");
            out.append("\n[SurfaceFlinger TimeStats]\n").append(sf).append('\n');
            CommandResult game = PrivilegedBridge.exec("cmd game help | head -n 30");
            out.append("\n[Game Service]\n").append(game).append('\n');
            String text = out.toString();
            runOnUiThread(() -> showDiagnosticDialog(text));
        });
    }

    private void showDiagnosticDialog(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextIsSelectable(true);
        tv.setTextColor(ContextCompat.getColor(this, R.color.vanta_text));
        tv.setTextSize(12);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        tv.setPadding(p, p, p, p);
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico VANTA")
                .setView(tv)
                .setPositiveButton("Fechar", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PrivilegedBridge.bindIfPossible();
        refreshStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PrivilegedBridge.removeStateListener(bridgeListener);
        io.shutdownNow();
    }
}
