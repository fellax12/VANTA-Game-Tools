package com.vanta.gametools;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ProfilesActivity extends AppCompatActivity {
    private AppListAdapter adapter;
    private TextView countText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);
        UiInsets.applySystemBars(findViewById(R.id.root));

        ListView list = findViewById(R.id.appsList);
        EditText search = findViewById(R.id.searchInput);
        countText = findViewById(R.id.countText);
        adapter = new AppListAdapter(this);
        list.setAdapter(adapter);
        loadApps();

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(String.valueOf(s));
                countText.setText(adapter.getCount() + " apps visíveis");
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        list.setOnItemClickListener((parent, view, position, id) -> {
            AppItem item = adapter.getItem(position);
            Intent intent = new Intent(this, ProfileEditorActivity.class);
            intent.putExtra("package", item.packageName);
            intent.putExtra("label", item.label);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) loadApps();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(launcher, 0);
        ProfileStore store = new ProfileStore(this);
        List<AppItem> items = new ArrayList<>();
        for (ResolveInfo info : infos) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (getPackageName().equals(pkg)) continue;
            String label = String.valueOf(info.loadLabel(pm));
            items.add(new AppItem(label, pkg, info.loadIcon(pm), store.hasProfile(pkg)));
        }
        items.sort(Comparator.comparing(a -> a.label.toLowerCase()));
        adapter.setItems(items);
        countText.setText(items.size() + " apps encontrados");
    }
}
