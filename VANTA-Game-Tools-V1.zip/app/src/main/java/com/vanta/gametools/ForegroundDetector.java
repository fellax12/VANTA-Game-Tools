package com.vanta.gametools;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ForegroundDetector {
    private static final Pattern COMPONENT = Pattern.compile("([A-Za-z0-9_.$]+)/(?:[A-Za-z0-9_.$]+)");

    private ForegroundDetector() {}

    public static String detectPackage() {
        String[] commands = new String[] {
                "dumpsys window windows | grep -m 1 'mCurrentFocus'",
                "dumpsys window windows | grep -m 1 'mFocusedApp'",
                "dumpsys activity activities | grep -m 1 'mResumedActivity'"
        };
        for (String command : commands) {
            CommandResult r = PrivilegedBridge.exec(command);
            if (!r.ok() || r.output.isEmpty()) continue;
            Matcher m = COMPONENT.matcher(r.output);
            if (m.find()) return m.group(1);
        }
        return "";
    }
}
