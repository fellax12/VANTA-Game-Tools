# VANTA Game Tools 1.1 alpha02

VANTA Game Tools é um toolkit Android para monitoramento e perfis de jogo usando Shizuku.

## V1.1 – correções do primeiro teste real

- Painel flutuante redesenhado para landscape: menor, com altura limitada e conteúdo rolável.
- Botões de minimizar (—) e fechar (×) ficam sempre visíveis no topo do painel.
- A bolha some enquanto o painel está expandido e volta ao minimizar.
- Arraste da bolha agora respeita os limites da tela.
- Estado do Shizuku separa autorização de conexão do serviço shell.
- UserService do Shizuku agora usa tag estável, versionamento e recuperação de binding travado.
- Botão de reconexão do Shizuku na tela principal.
- Seleção de jogo ficou explícita e aparece no topo da tela principal.
- Biblioteca prioriza apps marcados como jogos e mostra “CONFIGURAR ›” em cada linha.
- Ajustes de layout e botões para evitar texto cortado em telas estreitas/fontes maiores.
- Mantidos FPS/1% low/frame time/dropped frames, perfis, Game Mode, refresh e Super Resolution experimental.

## Fluxo de uso

1. Inicie o Shizuku.
2. Abra o VANTA e autorize-o no Shizuku.
3. Conceda a permissão de sobreposição.
4. Toque em “Selecionar / configurar jogo”.
5. Escolha um jogo, ajuste o perfil e salve/aplique.
6. Inicie o monitor flutuante e abra o jogo.
7. Toque na bolha `V • FPS` para abrir o painel compacto.

Algumas intervenções dependem do fabricante, versão do Android e do próprio jogo. O VANTA tenta registrar quando o sistema rejeita uma alteração.
