package com.vanta.gametools;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Display;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.Arrays;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextView shizukuStatus;
    private TextView shizukuDetail;
    private TextView overlayStatus;
    private TextView monitorStatus;
    private TextView monitorDetail;
    private TextView deviceInfo;
    private TextView selectedGameLabel;
    private TextView selectedGamePackage;
    private MaterialButton startButton;
    private MaterialButton shizukuButton;
    private MaterialAutoCompleteTextView sampleInterval;
    private ProfileStore store;

    private final PrivilegedBridge.StateListener bridgeListener = () -> runOnUiThread(this::refreshStatus);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UiInsets.applySystemBars(findViewById(R.id.contentRoot));
        PrivilegedBridge.init(this);
        PrivilegedBridge.addStateListener(bridgeListener);
        store = new ProfileStore(this);

        shizukuStatus = findViewById(R.id.shizukuStatus);
        shizukuDetail = findViewById(R.id.shizukuDetail);
        overlayStatus = findViewById(R.id.overlayStatus);
        monitorStatus = findViewById(R.id.monitorStatus);
        monitorDetail = findViewById(R.id.monitorDetail);
        deviceInfo = findViewById(R.id.deviceInfo);
        selectedGameLabel = findViewById(R.id.selectedGameLabel);
        selectedGamePackage = findViewById(R.id.selectedGamePackage);
        startButton = findViewById(R.id.startButton);
        shizukuButton = findViewById(R.id.shizukuButton);
        sampleInterval = findViewById(R.id.sampleInterval);

        shizukuButton.setOnClickListener(v -> handleShizukuButton());
        findViewById(R.id.overlayButton).setOnClickListener(v -> requestOverlay());
        findViewById(R.id.profilesButton).setOnClickListener(v -> startActivity(new Intent(this, ProfilesActivity.class)));
        findViewById(R.id.diagnosticsButton).setOnClickListener(v -> runDiagnostics());
        startButton.setOnClickListener(v -> toggleMonitor());

        setupSampleInterval();
        updateDeviceInfo();
        requestNotificationsIfNeeded();
        refreshSelectedGame();
        refreshStatus();
    }

    private void handleShizukuButton() {
        if (!PrivilegedBridge.isBinderAlive()) {
            Toast.makeText(this, "Abra o Shizuku e inicie o serviço por Depuração sem fio.", Toast.LENGTH_LONG).show();
            Intent launch = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (launch != null) startActivity(launch);
            return;
        }
        if (!PrivilegedBridge.hasPermission()) {
            PrivilegedBridge.requestPermission();
            return;
        }
        if (PrivilegedBridge.isReady()) {
            Toast.makeText(this, "Shizuku já está conectado e pronto.", Toast.LENGTH_SHORT).show();
            return;
        }
        PrivilegedBridge.forceReconnect();
        Toast.makeText(this, "Reconectando o serviço shell do Shizuku…", Toast.LENGTH_SHORT).show();
        getWindow().getDecorView().postDelayed(this::refreshStatus, 700);
    }

    private void setupSampleInterval() {
        String[] labels = {"0,5 s • mais responsivo", "1,0 s • recomendado", "1,5 s • econômico", "2,0 s • mínimo impacto"};
        int[] values = {500, 1000, 1500, 2000};
        sampleInterval.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, labels));
        int current = store.getSampleIntervalMs();
        int idx = 1;
        for (int i = 0; i < values.length; i++) if (values[i] == current) idx = i;
        sampleInterval.setText(labels[idx], false);
        sampleInterval.setOnItemClickListener((parent, view, position, id) -> store.setSampleIntervalMs(values[position]));
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 8801);
        }
    }

    private void requestOverlay() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Sobreposição já autorizada", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void toggleMonitor() {
        if (OverlayService.isRunning()) {
            stopService(new Intent(this, OverlayService.class));
            getWindow().getDecorView().postDelayed(this::refreshStatus, 350);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            requestOverlay();
            return;
        }
        if (!PrivilegedBridge.hasPermission()) {
            PrivilegedBridge.requestPermission();
            Toast.makeText(this, "Autorize o VANTA dentro do Shizuku antes de iniciar.", Toast.LENGTH_LONG).show();
            return;
        }
        PrivilegedBridge.bindIfPossible();
        ContextCompat.startForegroundService(this, new Intent(this, OverlayService.class));
        getWindow().getDecorView().postDelayed(this::refreshStatus, 500);
    }

    private void refreshStatus() {
        boolean binder = PrivilegedBridge.isBinderAlive();
        boolean permission = PrivilegedBridge.hasPermission();
        boolean ready = PrivilegedBridge.isReady();
        if (ready) {
            setChip(shizukuStatus, "PRONTO", true, false);
            shizukuButton.setText("SHIZUKU CONECTADO");
        } else if (binder && permission) {
            setChip(shizukuStatus, "AUTORIZADO", false, false);
            shizukuButton.setText("RECONECTAR SERVIÇO SHIZUKU");
        } else if (binder) {
            setChip(shizukuStatus, "AUTORIZAR", false, false);
            shizukuButton.setText("AUTORIZAR NO SHIZUKU");
        } else {
            setChip(shizukuStatus, "OFF", false, true);
            shizukuButton.setText("ABRIR SHIZUKU");
        }
        shizukuDetail.setText(PrivilegedBridge.statusText());

        boolean overlay = Settings.canDrawOverlays(this);
        setChip(overlayStatus, overlay ? "PERMITIDO" : "BLOQUEADO", overlay, !overlay);

        boolean running = OverlayService.isRunning();
        setChip(monitorStatus, running ? "ATIVO" : "OFF", running, false);
        monitorDetail.setText(running ? "Bolha e telemetria em execução" : "Parado");
        startButton.setText(running ? "PARAR MONITOR FLUTUANTE" : "INICIAR MONITOR FLUTUANTE");
    }

    private void refreshSelectedGame() {
        String pkg = store.getSelectedGamePackage();
        String label = store.getSelectedGameLabel();
        if (pkg == null || pkg.isEmpty()) {
            selectedGameLabel.setText("Nenhum jogo selecionado");
            selectedGamePackage.setText("Toque abaixo para escolher um jogo");
        } else {
            selectedGameLabel.setText(label == null || label.isEmpty() ? pkg : label);
            selectedGamePackage.setText(pkg);
        }
    }

    private void setChip(TextView view, String text, boolean ok, boolean bad) {
        view.setText(text);
        view.setBackgroundResource(ok ? R.drawable.bg_status_ok : bad ? R.drawable.bg_status_bad : R.drawable.bg_status_warn);
    }

    private void updateDeviceInfo() {
        Display display = getDisplay();
        TreeSet<Integer> rates = new TreeSet<>();
        if (display != null) {
            for (Display.Mode m : display.getSupportedModes()) rates.add(Math.round(m.getRefreshRate()));
        }
        String text = Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android " + Build.VERSION.RELEASE + " • API " + Build.VERSION.SDK_INT + "\n" +
                "Taxas da tela: " + Arrays.toString(rates.toArray()) + " Hz\n" +
                "VANTA " + BuildConfig.VERSION_NAME;
        deviceInfo.setText(text);
    }

    private void runDiagnostics() {
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico VANTA")
                .setMessage("Executando testes de Shizuku, foreground app, SurfaceFlinger e Game Service…")
                .setPositiveButton("OK", null)
                .show();
        io.execute(() -> {
            StringBuilder out = new StringBuilder();
            out.append("VANTA DIAGNOSTICS\n\n");
            out.append("Shizuku: ").append(PrivilegedBridge.statusText()).append('\n');
            CommandResult uid = PrivilegedBridge.exec("id");
            out.append("\n[id]\n").append(uid).append('\n');
            CommandResult focus = PrivilegedBridge.exec("dumpsys window windows | grep -m 1 'mCurrentFocus'");
            out.append("\n[foreground]\n").append(focus).append('\n');
            CommandResult sf = PrivilegedBridge.exec("dumpsys SurfaceFlinger --timestats -dump | head -n 35");
            out.append("\n[SurfaceFlinger TimeStats]\n").append(sf).append('\n');
            CommandResult game = PrivilegedBridge.exec("cmd game help | head -n 30");
            out.append("\n[Game Service]\n").append(game).append('\n');
            String text = out.toString();
            runOnUiThread(() -> showDiagnosticDialog(text));
        });
    }

    private void showDiagnosticDialog(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextIsSelectable(true);
        tv.setTextColor(ContextCompat.getColor(this, R.color.vanta_text));
        tv.setTextSize(12);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        tv.setPadding(p, p, p, p);
        new AlertDialog.Builder(this)
                .setTitle("Diagnóstico VANTA")
                .setView(tv)
                .setPositiveButton("Fechar", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PrivilegedBridge.bindIfPossible();
        refreshSelectedGame();
        refreshStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        PrivilegedBridge.removeStateListener(bridgeListener);
        io.shutdownNow();
    }
}
