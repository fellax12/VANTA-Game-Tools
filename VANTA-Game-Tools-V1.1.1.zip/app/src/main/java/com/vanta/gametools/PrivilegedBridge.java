package com.vanta.gametools;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.SystemClock;

import java.util.concurrent.CopyOnWriteArrayList;

import rikka.shizuku.Shizuku;

public final class PrivilegedBridge {
    public interface StateListener { void onStateChanged(); }

    public static final int REQUEST_CODE = 4901;
    private static final long BIND_TIMEOUT_MS = 6500L;
    private static volatile boolean initialized;
    private static volatile boolean binding;
    private static volatile long bindingStartedAt;
    private static volatile IPrivilegedService service;
    private static Context appContext;
    private static Shizuku.UserServiceArgs userServiceArgs;
    private static final CopyOnWriteArrayList<StateListener> listeners = new CopyOnWriteArrayList<>();

    private PrivilegedBridge() {}

    private static final Shizuku.OnBinderReceivedListener BINDER_RECEIVED = () -> {
        binding = false;
        bindingStartedAt = 0L;
        bindIfPossible();
        notifyState();
    };

    private static final Shizuku.OnBinderDeadListener BINDER_DEAD = () -> {
        service = null;
        binding = false;
        bindingStartedAt = 0L;
        notifyState();
    };

    private static final Shizuku.OnRequestPermissionResultListener PERMISSION_RESULT = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE && grantResult == PackageManager.PERMISSION_GRANTED) {
            bindIfPossible();
        }
        notifyState();
    };

    private static final ServiceConnection CONNECTION = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IPrivilegedService.Stub.asInterface(binder);
            binding = false;
            bindingStartedAt = 0L;
            notifyState();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
            binding = false;
            bindingStartedAt = 0L;
            notifyState();
        }
    };

    public static synchronized void init(Context context) {
        if (initialized) return;
        appContext = context.getApplicationContext();
        userServiceArgs = new Shizuku.UserServiceArgs(new ComponentName(appContext, PrivilegedService.class))
                .daemon(false)
                .tag("vanta_shell_service")
                .processNameSuffix("vanta_shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE);
        Shizuku.addBinderReceivedListenerSticky(BINDER_RECEIVED);
        Shizuku.addBinderDeadListener(BINDER_DEAD);
        Shizuku.addRequestPermissionResultListener(PERMISSION_RESULT);
        initialized = true;
        bindIfPossible();
    }

    public static void addStateListener(StateListener listener) {
        if (listener != null) listeners.addIfAbsent(listener);
    }

    public static void removeStateListener(StateListener listener) {
        listeners.remove(listener);
    }

    private static void notifyState() {
        for (StateListener listener : listeners) {
            try { listener.onStateChanged(); } catch (Throwable ignored) {}
        }
    }

    public static boolean isBinderAlive() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    public static boolean hasPermission() {
        if (!isBinderAlive()) return false;
        try { return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    public static boolean isReady() {
        IPrivilegedService s = service;
        if (!hasPermission() || s == null) return false;
        try {
            int uid = s.uid();
            return uid == 0 || uid == 2000 || uid > 0;
        } catch (Throwable t) {
            service = null;
            binding = false;
            bindingStartedAt = 0L;
            return false;
        }
    }

    public static boolean isBinding() {
        if (binding && bindingStartedAt > 0L && SystemClock.elapsedRealtime() - bindingStartedAt > BIND_TIMEOUT_MS) {
            recoverStuckBinding();
        }
        return binding;
    }

    public static int shizukuUid() {
        if (!isBinderAlive()) return -1;
        try { return Shizuku.getUid(); } catch (Throwable t) { return -1; }
    }

    public static void requestPermission() {
        if (!isBinderAlive()) return;
        if (hasPermission()) {
            bindIfPossible();
            return;
        }
        try { Shizuku.requestPermission(REQUEST_CODE); } catch (Throwable ignored) {}
    }

    public static synchronized void bindIfPossible() {
        if (!initialized || service != null || !hasPermission()) return;
        if (binding) {
            if (bindingStartedAt > 0L && SystemClock.elapsedRealtime() - bindingStartedAt > BIND_TIMEOUT_MS) {
                recoverStuckBinding();
            } else {
                return;
            }
        }
        try {
            binding = true;
            bindingStartedAt = SystemClock.elapsedRealtime();
            Shizuku.bindUserService(userServiceArgs, CONNECTION);
        } catch (Throwable t) {
            binding = false;
            bindingStartedAt = 0L;
            service = null;
        }
    }

    private static synchronized void recoverStuckBinding() {
        if (!initialized || userServiceArgs == null) return;
        try { Shizuku.unbindUserService(userServiceArgs, CONNECTION, true); } catch (Throwable ignored) {}
        service = null;
        binding = false;
        bindingStartedAt = 0L;
    }

    public static synchronized void forceReconnect() {
        if (!initialized || userServiceArgs == null || !hasPermission()) return;
        try { Shizuku.unbindUserService(userServiceArgs, CONNECTION, true); } catch (Throwable ignored) {}
        service = null;
        binding = false;
        bindingStartedAt = 0L;
        bindIfPossible();
        notifyState();
    }

    public static CommandResult exec(String command) {
        IPrivilegedService s = service;
        if (s == null) {
            bindIfPossible();
            return new CommandResult(-994, isBinderAlive() && hasPermission()
                    ? "Shizuku autorizado; preparando serviço shell"
                    : "Shizuku indisponível ou sem autorização");
        }
        try {
            return CommandResult.fromWire(s.exec(command));
        } catch (Throwable t) {
            service = null;
            binding = false;
            bindingStartedAt = 0L;
            bindIfPossible();
            return new CommandResult(-993, t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage()));
        }
    }

    public static String statusText() {
        if (!isBinderAlive()) return "Shizuku não está em execução";
        if (!hasPermission()) return "Shizuku ativo, aguardando autorização";
        if (service == null) {
            return isBinding()
                    ? "Autorizado • preparando serviço shell…"
                    : "Autorizado • toque em reconectar se não ficar pronto";
        }
        int uid = shizukuUid();
        return "Pronto • UID " + uid + (uid == 2000 ? " (ADB)" : uid == 0 ? " (root)" : "");
    }
}
