package com.vanta.gametools;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileEditorActivity extends AppCompatActivity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private String pkg;
    private String label;
    private ProfileStore store;
    private MaterialSwitch enabledSwitch;
    private MaterialSwitch autoApplySwitch;
    private MaterialAutoCompleteTextView gameMode;
    private MaterialAutoCompleteTextView fpsCap;
    private MaterialAutoCompleteTextView refreshRate;
    private MaterialAutoCompleteTextView upscale;
    private TextView resultText;

    private static final LinkedHashMap<String, String> MODE_MAP = new LinkedHashMap<>();
    private static final LinkedHashMap<String, Integer> FPS_MAP = new LinkedHashMap<>();
    private static final LinkedHashMap<String, Integer> HZ_MAP = new LinkedHashMap<>();
    private static final LinkedHashMap<String, String> UPSCALE_MAP = new LinkedHashMap<>();
    static {
        MODE_MAP.put("Padrão", "standard");
        MODE_MAP.put("Performance", "performance");
        MODE_MAP.put("Economia", "battery");

        FPS_MAP.put("Sem limite pelo VANTA", 0);
        FPS_MAP.put("30 FPS", 30);
        FPS_MAP.put("45 FPS", 45);
        FPS_MAP.put("60 FPS", 60);
        FPS_MAP.put("90 FPS", 90);

        HZ_MAP.put("Automático / não alterar", 0);
        HZ_MAP.put("60 Hz", 60);
        HZ_MAP.put("90 Hz", 90);

        UPSCALE_MAP.put("Original", "1.00");
        UPSCALE_MAP.put("1.11×", "1.11");
        UPSCALE_MAP.put("1.18×", "1.18");
        UPSCALE_MAP.put("1.25×", "1.25");
        UPSCALE_MAP.put("1.33×", "1.33");
        UPSCALE_MAP.put("1.43×", "1.43");
        UPSCALE_MAP.put("1.54×", "1.54");
        UPSCALE_MAP.put("1.67×", "1.67");
        UPSCALE_MAP.put("1.82×", "1.82");
        UPSCALE_MAP.put("2.00×", "2.00");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_editor);
        UiInsets.applySystemBars(findViewById(R.id.root));
        PrivilegedBridge.init(this);

        pkg = getIntent().getStringExtra("package");
        label = getIntent().getStringExtra("label");
        if (pkg == null || pkg.isEmpty()) {
            finish();
            return;
        }
        if (label == null || label.isEmpty()) label = pkg;
        store = new ProfileStore(this);
        store.setSelectedGame(pkg, label);

        ((TextView) findViewById(R.id.appName)).setText(label);
        ((TextView) findViewById(R.id.packageName)).setText(pkg);
        enabledSwitch = findViewById(R.id.enabledSwitch);
        autoApplySwitch = findViewById(R.id.autoApplySwitch);
        gameMode = findViewById(R.id.gameMode);
        fpsCap = findViewById(R.id.fpsCap);
        refreshRate = findViewById(R.id.refreshRate);
        upscale = findViewById(R.id.upscale);
        resultText = findViewById(R.id.resultText);

        setupDropdown(gameMode, MODE_MAP.keySet().toArray(new String[0]));
        setupDropdown(fpsCap, FPS_MAP.keySet().toArray(new String[0]));
        setupDropdown(refreshRate, HZ_MAP.keySet().toArray(new String[0]));
        setupDropdown(upscale, UPSCALE_MAP.keySet().toArray(new String[0]));
        loadProfile();

        MaterialButton save = findViewById(R.id.saveButton);
        MaterialButton apply = findViewById(R.id.applyButton);
        MaterialButton applyLaunch = findViewById(R.id.applyLaunchButton);
        MaterialButton reset = findViewById(R.id.resetButton);

        save.setOnClickListener(v -> {
            store.saveProfile(pkg, readProfile());
            Toast.makeText(this, "Perfil salvo", Toast.LENGTH_SHORT).show();
        });
        apply.setOnClickListener(v -> apply(false));
        applyLaunch.setOnClickListener(v -> apply(true));
        reset.setOnClickListener(v -> resetChanges());
    }

    private void setupDropdown(MaterialAutoCompleteTextView view, String[] values) {
        view.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, values));
    }

    private void loadProfile() {
        GameProfile p = store.getProfile(pkg);
        enabledSwitch.setChecked(p.enabled);
        autoApplySwitch.setChecked(p.autoApply);
        gameMode.setText(labelFor(MODE_MAP, p.gameMode, "Performance"), false);
        fpsCap.setText(labelFor(FPS_MAP, p.fpsCap, "Sem limite pelo VANTA"), false);
        refreshRate.setText(labelFor(HZ_MAP, p.refreshRate, "Automático / não alterar"), false);
        upscale.setText(labelFor(UPSCALE_MAP, p.upscaleFactor, "Original"), false);
    }

    private static <T> String labelFor(Map<String, T> map, T value, String fallback) {
        for (Map.Entry<String, T> e : map.entrySet()) {
            if (e.getValue().equals(value)) return e.getKey();
        }
        return fallback;
    }

    private GameProfile readProfile() {
        GameProfile p = new GameProfile();
        p.enabled = enabledSwitch.isChecked();
        p.autoApply = autoApplySwitch.isChecked();
        p.gameMode = MODE_MAP.getOrDefault(String.valueOf(gameMode.getText()), "performance");
        p.fpsCap = FPS_MAP.getOrDefault(String.valueOf(fpsCap.getText()), 0);
        p.refreshRate = HZ_MAP.getOrDefault(String.valueOf(refreshRate.getText()), 0);
        p.upscaleFactor = UPSCALE_MAP.getOrDefault(String.valueOf(upscale.getText()), "1.00");
        return p;
    }

    private void apply(boolean launchAfter) {
        GameProfile p = readProfile();
        store.saveProfile(pkg, p);
        resultText.setText("Aplicando alterações via Shizuku…");
        if (!PrivilegedBridge.hasPermission()) {
            PrivilegedBridge.requestPermission();
            resultText.setText("Autorize o Shizuku e toque novamente em Aplicar.");
            return;
        }
        PrivilegedBridge.bindIfPossible();
        io.execute(() -> {
            String result = new GameTuner(this).applyProfile(pkg, p, true);
            runOnUiThread(() -> {
                resultText.setText(result);
                if (launchAfter) {
                    if (Settings.canDrawOverlays(this) && !OverlayService.isRunning()) {
                        ContextCompat.startForegroundService(this, new Intent(this, OverlayService.class));
                    }
                    Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (launch != null) startActivity(launch);
                    else Toast.makeText(this, "Não encontrei Activity de inicialização", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private void resetChanges() {
        resultText.setText("Restaurando alterações do VANTA…");
        io.execute(() -> {
            GameTuner tuner = new GameTuner(this);
            String result = tuner.resetVantaChanges(pkg) + "\n" + tuner.restoreRefreshRate();
            runOnUiThread(() -> resultText.setText(result));
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }
}
