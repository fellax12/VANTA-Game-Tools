# VANTA Game Tools V1.3.1

Compatibilidade Shizuku revisada:
- execução via AIDL direto, sem reflexão;
- /system/bin/sh absoluto;
- fallback shell por stdin;
- diagnóstico mostra a estratégia de shell usada;
- mantém overlay, seleção de jogo, perfis e telemetria da V1.3.
