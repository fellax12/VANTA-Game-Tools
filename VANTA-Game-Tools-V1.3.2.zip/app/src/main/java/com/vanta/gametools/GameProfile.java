package com.vanta.gametools;

public class GameProfile {
    public boolean enabled = true;
    public boolean autoApply = true;
    public String gameMode = "performance";
    public int fpsCap = 0;
    public int refreshRate = 0;
    public String upscaleFactor = "1.00";

    public String encode() {
        return (enabled ? "1" : "0") + "|" +
                (autoApply ? "1" : "0") + "|" +
                gameMode + "|" + fpsCap + "|" + refreshRate + "|" + upscaleFactor;
    }

    public static GameProfile decode(String value) {
        GameProfile p = new GameProfile();
        if (value == null || value.isEmpty()) return p;
        String[] s = value.split("\\|", -1);
        try {
            if (s.length > 0) p.enabled = "1".equals(s[0]);
            if (s.length > 1) p.autoApply = "1".equals(s[1]);
            if (s.length > 2 && !s[2].isEmpty()) p.gameMode = s[2];
            if (s.length > 3) p.fpsCap = Integer.parseInt(s[3]);
            if (s.length > 4) p.refreshRate = Integer.parseInt(s[4]);
            if (s.length > 5 && !s[5].isEmpty()) p.upscaleFactor = s[5];
        } catch (Throwable ignored) {}
        return p;
    }
}
