package com.vanta.gametools;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AppListAdapter extends BaseAdapter {
    private final LayoutInflater inflater;
    private final List<AppItem> all = new ArrayList<>();
    private final List<AppItem> visible = new ArrayList<>();

    public AppListAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public void setItems(List<AppItem> items) {
        all.clear();
        all.addAll(items);
        visible.clear();
        visible.addAll(items);
        notifyDataSetChanged();
    }

    public void filter(String query) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        visible.clear();
        if (q.isEmpty()) {
            visible.addAll(all);
        } else {
            for (AppItem item : all) {
                if (item.label.toLowerCase(Locale.ROOT).contains(q) || item.packageName.toLowerCase(Locale.ROOT).contains(q)) {
                    visible.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    @Override public int getCount() { return visible.size(); }
    @Override public AppItem getItem(int position) { return visible.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.row_app, parent, false);
            h = new ViewHolder();
            h.icon = convertView.findViewById(R.id.icon);
            h.title = convertView.findViewById(R.id.title);
            h.subtitle = convertView.findViewById(R.id.subtitle);
            h.badge = convertView.findViewById(R.id.badge);
            h.action = convertView.findViewById(R.id.actionLabel);
            convertView.setTag(h);
        } else {
            h = (ViewHolder) convertView.getTag();
        }
        AppItem item = getItem(position);
        h.icon.setImageDrawable(item.icon);
        h.title.setText(item.label);
        h.subtitle.setText(item.packageName);
        if (item.hasProfile) {
            h.badge.setText("PERFIL");
            h.badge.setVisibility(View.VISIBLE);
        } else if (item.isGame) {
            h.badge.setText("JOGO");
            h.badge.setVisibility(View.VISIBLE);
        } else {
            h.badge.setVisibility(View.GONE);
        }
        h.action.setText("CONFIGURAR ›");
        return convertView;
    }

    private static class ViewHolder {
        ImageView icon;
        TextView title;
        TextView subtitle;
        TextView badge;
        TextView action;
    }
}
