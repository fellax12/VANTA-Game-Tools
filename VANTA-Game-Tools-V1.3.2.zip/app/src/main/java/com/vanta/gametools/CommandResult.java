package com.vanta.gametools;

public final class CommandResult {
    public final int exitCode;
    public final String output;

    public CommandResult(int exitCode, String output) {
        this.exitCode = exitCode;
        this.output = output == null ? "" : output.trim();
    }

    public boolean ok() {
        return exitCode == 0;
    }

    public static CommandResult fromWire(String wire) {
        if (wire == null) return new CommandResult(-998, "Resposta nula do serviço privilegiado");
        final String prefix = "__VANTA_EXIT__=";
        if (!wire.startsWith(prefix)) return new CommandResult(-997, wire);
        int nl = wire.indexOf('\n');
        String code = nl >= 0 ? wire.substring(prefix.length(), nl) : wire.substring(prefix.length());
        String body = nl >= 0 ? wire.substring(nl + 1) : "";
        try {
            return new CommandResult(Integer.parseInt(code.trim()), body);
        } catch (NumberFormatException e) {
            return new CommandResult(-996, wire);
        }
    }

    @Override
    public String toString() {
        return "exit=" + exitCode + (output.isEmpty() ? "" : "\n" + output);
    }
}
