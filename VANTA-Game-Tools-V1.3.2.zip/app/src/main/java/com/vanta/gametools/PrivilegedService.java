package com.vanta.gametools;

import android.content.Context;
import android.os.RemoteException;
import android.system.Os;

import androidx.annotation.Keep;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

public class PrivilegedService extends IPrivilegedService.Stub {

    public PrivilegedService() {}

    @Keep
    public PrivilegedService(Context context) {}

    @Override
    public String exec(String command) throws RemoteException {
        if (command == null || command.trim().isEmpty()) {
            return "__VANTA_EXIT__=2\nComando vazio";
        }
        Process process = null;
        try {
            process = new ProcessBuilder("sh", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    out.append(line).append('\n');
                    if (out.length() > 600_000) {
                        out.append("[saída truncada pelo VANTA]\n");
                        break;
                    }
                }
            }
            boolean done = process.waitFor(12, TimeUnit.SECONDS);
            if (!done) {
                process.destroyForcibly();
                return "__VANTA_EXIT__=-999\nTimeout após 12 s";
            }
            return "__VANTA_EXIT__=" + process.exitValue() + "\n" + out;
        } catch (Throwable t) {
            return "__VANTA_EXIT__=-995\n" + t.getClass().getSimpleName() + ": " + String.valueOf(t.getMessage());
        } finally {
            if (process != null) process.destroy();
        }
    }

    @Override
    public int uid() {
        return Os.getuid();
    }

    @Override
    public void destroy() {
        System.exit(0);
    }
}
