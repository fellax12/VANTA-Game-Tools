package com.vanta.gametools;

public class FpsSnapshot {
    public String packageName = "";
    public String layerName = "";
    public double fps = 0;
    public double onePercentLow = 0;
    public double frameTimeMs = 0;
    public int displayRefreshRate = 0;
    public long totalFrames = 0;
    public long droppedFrames = 0;
    public long timestampMs = System.currentTimeMillis();

    public boolean hasData() {
        return fps > 0.1;
    }

    public double droppedPercent() {
        if (totalFrames <= 0) return 0;
        return (droppedFrames * 100.0) / totalFrames;
    }
}
