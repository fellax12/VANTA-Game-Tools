package com.vanta.gametools;

import android.os.IBinder;
import android.os.ParcelFileDescriptor;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import moe.shizuku.server.IRemoteProcess;
import moe.shizuku.server.IShizukuService;
import rikka.shizuku.Shizuku;

/**
 * Shell backend using Shizuku's public binder plus the AIDL interface shipped
 * by dev.rikka.shizuku:api. No reflection is used.
 *
 * Some OEM builds reject Runtime.exec-style arrays containing `sh -c ...`.
 * VANTA therefore has two strategies:
 *  1) /system/bin/sh -c <command>
 *  2) open /system/bin/sh and write the command through stdin
 */
public final class DirectShizukuShell {
    private static final int MAX_OUTPUT_CHARS = 700_000;
    private static final long TIMEOUT_SECONDS = 12L;
    private static final ExecutorService IO = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "vanta-shizuku-io");
        t.setDaemon(true);
        return t;
    });

    private static volatile String lastError = "";
    private static volatile String lastStrategy = "";
    private static volatile boolean lastLaunchWorked;

    private DirectShizukuShell() {}

    private static IShizukuService remoteService() {
        try {
            IBinder binder = Shizuku.getBinder();
            if (binder == null || !binder.pingBinder()) {
                lastError = "Binder do Shizuku indisponível";
                return null;
            }
            return IShizukuService.Stub.asInterface(binder);
        } catch (Throwable t) {
            lastError = describe(t);
            return null;
        }
    }

    public static boolean available() {
        try {
            if (!Shizuku.pingBinder()) return false;
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;
            int uid = Shizuku.getUid();
            return (uid == 0 || uid == 2000) && remoteService() != null;
        } catch (Throwable t) {
            lastError = describe(t);
            return false;
        }
    }

    public static int uid() {
        try { return available() ? Shizuku.getUid() : -1; }
        catch (Throwable t) { return -1; }
    }

    public static String lastError() {
        return lastError == null ? "" : lastError;
    }

    public static String strategy() {
        return lastStrategy == null ? "" : lastStrategy;
    }

    public static boolean lastLaunchWorked() {
        return lastLaunchWorked;
    }

    public static void reset() {
        lastError = "";
        lastStrategy = "";
        lastLaunchWorked = false;
    }

    public static CommandResult exec(String command) {
        if (command == null || command.trim().isEmpty()) {
            return new CommandResult(2, "Comando vazio");
        }
        if (!available()) {
            return new CommandResult(-991, "Shell do Shizuku indisponível" + suffix(lastError()));
        }

        // Strategy A: normal Runtime.exec style.
        CommandResult first = runRemote(command, false);
        if (!isLaunchFailure(first)) return first;

        // Strategy B: start only /system/bin/sh and feed command through stdin.
        // This avoids ROM/server quirks around argument arrays passed to newProcess.
        CommandResult second = runRemote(command, true);
        if (!isLaunchFailure(second)) return second;

        String a = compact(first.output);
        String b = compact(second.output);
        String combined = "Falha ao iniciar shell Shizuku. A=" + a + " | B=" + b;
        lastError = combined;
        lastLaunchWorked = false;
        return new CommandResult(-988, combined);
    }

    private static CommandResult runRemote(String command, boolean stdinMode) {
        IRemoteProcess remote = null;
        Future<String> stdoutFuture = null;
        Future<String> stderrFuture = null;
        Future<Integer> waitFuture = null;
        try {
            IShizukuService service = remoteService();
            if (service == null) return new CommandResult(-991, lastError());

            String[] argv = stdinMode
                    ? new String[]{"/system/bin/sh"}
                    : new String[]{"/system/bin/sh", "-c", command};

            // Explicit working directory avoids OEM implementations that dislike
            // a null cwd while remaining equivalent for our absolute binaries.
            remote = service.newProcess(argv, null, "/");
            if (remote == null) {
                return new CommandResult(-989, "newProcess retornou null");
            }

            final IRemoteProcess rp = remote;
            final ParcelFileDescriptor outFd = rp.getInputStream();
            final ParcelFileDescriptor errFd = rp.getErrorStream();
            if (outFd == null || errFd == null) {
                return new CommandResult(-986, "Shizuku retornou streams nulos");
            }

            stdoutFuture = IO.submit(() -> readBounded(new ParcelFileDescriptor.AutoCloseInputStream(outFd)));
            stderrFuture = IO.submit(() -> readBounded(new ParcelFileDescriptor.AutoCloseInputStream(errFd)));

            if (stdinMode) {
                ParcelFileDescriptor inFd = rp.getOutputStream();
                if (inFd == null) return new CommandResult(-985, "stdin remoto indisponível");
                try (OutputStream stdin = new ParcelFileDescriptor.AutoCloseOutputStream(inFd)) {
                    stdin.write(command.getBytes(StandardCharsets.UTF_8));
                    stdin.write('\n');
                    stdin.write("exit\n".getBytes(StandardCharsets.UTF_8));
                    stdin.flush();
                }
            }

            waitFuture = IO.submit(rp::waitFor);
            int code;
            try {
                code = waitFuture.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
            } catch (java.util.concurrent.TimeoutException timeout) {
                try { rp.destroy(); } catch (Throwable ignored) {}
                cancel(waitFuture);
                cancel(stdoutFuture);
                cancel(stderrFuture);
                return new CommandResult(-999, "Timeout após " + TIMEOUT_SECONDS + " s");
            }

            String stdout = getFuture(stdoutFuture);
            String stderr = getFuture(stderrFuture);
            String output;
            if (stdout.isEmpty()) output = stderr;
            else if (stderr.isEmpty()) output = stdout;
            else output = stdout + "\n" + stderr;

            lastLaunchWorked = true;
            lastStrategy = stdinMode ? "AIDL shell/stdin" : "AIDL sh -c";
            lastError = "";
            return new CommandResult(code, output);
        } catch (Throwable t) {
            Throwable root = unwrap(t);
            String detail = describe(root);
            lastError = detail;
            lastLaunchWorked = false;
            lastStrategy = stdinMode ? "AIDL shell/stdin" : "AIDL sh -c";
            return new CommandResult(-987, detail);
        } finally {
            if (remote != null) {
                try { remote.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    private static boolean isLaunchFailure(CommandResult r) {
        if (r == null) return true;
        return r.exitCode == -991 || r.exitCode == -989 || r.exitCode == -988 ||
                r.exitCode == -987 || r.exitCode == -986 || r.exitCode == -985;
    }

    private static String readBounded(InputStream stream) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int n;
            while ((n = reader.read(buffer)) >= 0) {
                if (n == 0) continue;
                int room = MAX_OUTPUT_CHARS - out.length();
                if (room <= 0) {
                    out.append("\n[saída truncada pelo VANTA]");
                    break;
                }
                out.append(buffer, 0, Math.min(n, room));
            }
        }
        return out.toString().trim();
    }

    private static String getFuture(Future<String> future) {
        if (future == null) return "";
        try { return future.get(2, TimeUnit.SECONDS); }
        catch (Throwable t) {
            future.cancel(true);
            return "";
        }
    }

    private static void cancel(Future<?> future) {
        if (future != null) future.cancel(true);
    }

    private static Throwable unwrap(Throwable t) {
        Throwable cur = t;
        for (int i = 0; i < 4; i++) {
            if (cur instanceof java.lang.reflect.InvocationTargetException &&
                    ((java.lang.reflect.InvocationTargetException) cur).getCause() != null) {
                cur = ((java.lang.reflect.InvocationTargetException) cur).getCause();
                continue;
            }
            if (cur.getCause() != null && (cur instanceof RuntimeException) &&
                    (cur.getMessage() == null || cur.getMessage().isEmpty())) {
                cur = cur.getCause();
                continue;
            }
            break;
        }
        return cur;
    }

    private static String describe(Throwable t) {
        if (t == null) return "erro desconhecido";
        String msg = String.valueOf(t.getMessage());
        if ("null".equals(msg)) msg = "sem mensagem";
        return t.getClass().getSimpleName() + ": " + msg;
    }

    private static String suffix(String s) {
        return s == null || s.isEmpty() ? "" : ": " + s;
    }

    private static String compact(String s) {
        if (s == null || s.trim().isEmpty()) return "sem resposta";
        String x = s.replace('\n', ' ').replace('\r', ' ').trim();
        return x.length() > 120 ? x.substring(0, 120) + "…" : x;
    }
}
