package com.vanta.gametools;

import android.content.Context;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class GameTuner {
    public static final long DOWNSCALED = 168419799L;
    public static final long DOWNSCALED_INVERSE = 273564678L;

    private static final LinkedHashMap<String, Long> UPSCALE_IDS = new LinkedHashMap<>();
    static {
        UPSCALE_IDS.put("1.11", 182811243L); // inverse 90%
        UPSCALE_IDS.put("1.18", 189969734L); // inverse 85%
        UPSCALE_IDS.put("1.25", 176926753L); // inverse 80%
        UPSCALE_IDS.put("1.33", 189969779L); // inverse 75%
        UPSCALE_IDS.put("1.43", 176926829L); // inverse 70%
        UPSCALE_IDS.put("1.54", 189969744L); // inverse 65%
        UPSCALE_IDS.put("1.67", 176926771L); // inverse 60%
        UPSCALE_IDS.put("1.82", 189970036L); // inverse 55%
        UPSCALE_IDS.put("2.00", 176926741L); // inverse 50%
    }

    private final ProfileStore store;

    public GameTuner(Context context) {
        this.store = new ProfileStore(context);
    }

    public static String shellQuote(String value) {
        return "'" + value.replace("'", "'\\''") + "'";
    }

    private static void append(StringBuilder log, String title, CommandResult r) {
        log.append("\n").append(title).append(": ")
                .append(r.ok() ? "OK" : "FALHOU")
                .append(" [exit ").append(r.exitCode).append("]");
        if (!r.output.isEmpty()) log.append("\n").append(r.output);
        log.append("\n");
    }

    public String applyProfile(String pkg, GameProfile p, boolean includeRefresh) {
        StringBuilder log = new StringBuilder("VANTA • aplicação de perfil\n").append(pkg).append("\n");
        if (!PrivilegedBridge.isReady()) return log.append("\nShizuku ainda não está pronto.").toString();

        String mode = ("battery".equals(p.gameMode) || "standard".equals(p.gameMode)) ? p.gameMode : "performance";
        CommandResult modeResult = PrivilegedBridge.exec("cmd game mode " + mode + " " + shellQuote(pkg));
        append(log, "Game Mode " + mode, modeResult);

        if (p.fpsCap > 0) {
            ensureGameOverlayBackup(pkg, log);
            String config = "mode=2,fps=" + p.fpsCap + ":mode=3,fps=" + p.fpsCap;
            CommandResult fps = PrivilegedBridge.exec("device_config put game_overlay " + shellQuote(pkg) + " " + shellQuote(config));
            append(log, "Intervenção FPS " + p.fpsCap, fps);
            CommandResult verify = PrivilegedBridge.exec("device_config get game_overlay " + shellQuote(pkg));
            append(log, "Verificação game_overlay", verify);
        } else if (store.hasOverlayBackup(pkg)) {
            restoreGameOverlayBackup(pkg, log, false);
        }

        applyUpscale(pkg, p.upscaleFactor, log);

        if (includeRefresh && p.refreshRate > 0) {
            applyRefreshRate(p.refreshRate, log);
        }

        log.append("\nObservação: alterações de resolução/Game Mode podem exigir reiniciar o jogo.");
        return log.toString();
    }

    private void ensureGameOverlayBackup(String pkg, StringBuilder log) {
        if (store.hasOverlayBackup(pkg)) return;
        CommandResult current = PrivilegedBridge.exec("device_config get game_overlay " + shellQuote(pkg));
        if (current.ok()) {
            String value = current.output.trim();
            store.saveOverlayBackup(pkg, value.isEmpty() || "null".equalsIgnoreCase(value) ? null : value);
            log.append("\nBackup do game_overlay salvo.");
        } else {
            log.append("\nNão foi possível salvar backup do game_overlay: ").append(current.output);
        }
    }


    private void restoreGameOverlayBackup(String pkg, StringBuilder log, boolean clearBackup) {
        String backup = store.getOverlayBackup(pkg);
        CommandResult r;
        if (backup == null || "__NULL__".equals(backup)) {
            r = PrivilegedBridge.exec("device_config delete game_overlay " + shellQuote(pkg));
        } else {
            r = PrivilegedBridge.exec("device_config put game_overlay " + shellQuote(pkg) + " " + shellQuote(backup));
        }
        append(log, "Restaurar game_overlay original", r);
        if (clearBackup && r.ok()) store.clearOverlayBackup(pkg);
    }

    private void applyUpscale(String pkg, String factor, StringBuilder log) {
        resetScaleOverrides(pkg, log, false);
        if (factor == null || "1.00".equals(factor)) {
            log.append("\nSuper Resolution: original (overrides do VANTA limpos).\n");
            return;
        }
        Long factorId = UPSCALE_IDS.get(factor);
        if (factorId == null) {
            log.append("\nSuper Resolution: fator desconhecido ").append(factor).append("\n");
            return;
        }
        CommandResult gate = PrivilegedBridge.exec("am compat enable " + DOWNSCALED_INVERSE + " " + shellQuote(pkg));
        append(log, "Inverse scaling gate", gate);
        if (!gate.ok() || containsRejection(gate.output)) {
            log.append("Android/OEM rejeitou o override para este app; o VANTA não marcará o upscale como efetivo.\n");
            return;
        }
        CommandResult factorResult = PrivilegedBridge.exec("am compat enable " + factorId + " " + shellQuote(pkg));
        append(log, "Super Resolution " + factor + "x", factorResult);
        if (factorResult.ok() && !containsRejection(factorResult.output)) {
            log.append("Solicitação aceita pelo framework. Confirme visualmente após reabrir o jogo.\n");
        } else {
            log.append("O sistema não aceitou o fator solicitado.\n");
        }
    }

    private static boolean containsRejection(String s) {
        String v = s == null ? "" : s.toLowerCase(Locale.ROOT);
        return v.contains("cannot override") || v.contains("not debuggable") || v.contains("permission denial") || v.contains("securityexception") || v.contains("not allowed");
    }

    public void resetScaleOverrides(String pkg, StringBuilder log, boolean verbose) {
        for (Map.Entry<String, Long> entry : UPSCALE_IDS.entrySet()) {
            CommandResult r = PrivilegedBridge.exec("am compat reset " + entry.getValue() + " " + shellQuote(pkg));
            if (verbose && !r.ok()) append(log, "Reset scale " + entry.getKey(), r);
        }
        CommandResult inv = PrivilegedBridge.exec("am compat reset " + DOWNSCALED_INVERSE + " " + shellQuote(pkg));
        CommandResult normal = PrivilegedBridge.exec("am compat reset " + DOWNSCALED + " " + shellQuote(pkg));
        if (verbose) {
            append(log, "Reset inverse gate", inv);
            append(log, "Reset downscale gate", normal);
        }
    }

    public void applyRefreshRate(int hz, StringBuilder log) {
        if (hz <= 0) return;
        if (!store.hasRefreshBackup()) {
            CommandResult min = PrivilegedBridge.exec("settings get system min_refresh_rate");
            CommandResult peak = PrivilegedBridge.exec("settings get system peak_refresh_rate");
            if (min.ok() && peak.ok()) {
                store.saveRefreshBackup(normalizeSetting(min.output), normalizeSetting(peak.output));
                log.append("\nBackup de refresh rate salvo.");
            }
        }
        String value = hz + ".0";
        CommandResult peak = PrivilegedBridge.exec("settings put system peak_refresh_rate " + value);
        CommandResult min = PrivilegedBridge.exec("settings put system min_refresh_rate " + value);
        append(log, "Refresh peak " + hz + " Hz", peak);
        append(log, "Refresh min " + hz + " Hz", min);
    }

    private static String normalizeSetting(String s) {
        if (s == null) return null;
        String v = s.trim();
        return v.isEmpty() || "null".equalsIgnoreCase(v) ? null : v;
    }

    public String restoreRefreshRate() {
        if (!store.hasRefreshBackup() || !PrivilegedBridge.isReady()) return "Sem backup global de refresh para restaurar.";
        StringBuilder log = new StringBuilder();
        restoreSetting("min_refresh_rate", store.getRefreshMinBackup(), log);
        restoreSetting("peak_refresh_rate", store.getRefreshPeakBackup(), log);
        store.clearRefreshBackup();
        return log.toString();
    }

    private void restoreSetting(String key, String value, StringBuilder log) {
        CommandResult r;
        if (value == null || "__NULL__".equals(value)) {
            r = PrivilegedBridge.exec("settings delete system " + key);
        } else {
            r = PrivilegedBridge.exec("settings put system " + key + " " + shellQuote(value));
        }
        append(log, "Restaurar " + key, r);
    }

    public String resetVantaChanges(String pkg) {
        StringBuilder log = new StringBuilder("VANTA • restauração\n").append(pkg).append("\n");
        if (!PrivilegedBridge.isReady()) return log.append("\nShizuku ainda não está pronto.").toString();
        resetScaleOverrides(pkg, log, true);
        append(log, "Game Mode standard", PrivilegedBridge.exec("cmd game mode standard " + shellQuote(pkg)));

        if (store.hasOverlayBackup(pkg)) {
            restoreGameOverlayBackup(pkg, log, true);
        } else {
            log.append("\nSem backup game_overlay criado pelo VANTA para este pacote.\n");
        }
        return log.toString();
    }
}
