package com.vanta.gametools;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProfilesActivity extends AppCompatActivity {
    private AppListAdapter adapter;
    private TextView countText;
    private TextView selectedText;
    private ProfileStore store;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profiles);
        UiInsets.applySystemBars(findViewById(R.id.root));
        store = new ProfileStore(this);

        ListView list = findViewById(R.id.appsList);
        EditText search = findViewById(R.id.searchInput);
        countText = findViewById(R.id.countText);
        selectedText = findViewById(R.id.selectedText);
        adapter = new AppListAdapter(this);
        list.setAdapter(adapter);
        list.setChoiceMode(ListView.CHOICE_MODE_NONE);
        loadApps();
        refreshSelected();

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter.filter(String.valueOf(s));
                countText.setText(adapter.getCount() + " apps visíveis • toque em um para configurar");
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        list.setOnItemClickListener((parent, view, position, id) -> {
            AppItem item = adapter.getItem(position);
            store.setSelectedGame(item.packageName, item.label);
            refreshSelected();
            Intent intent = new Intent(this, ProfileEditorActivity.class);
            intent.putExtra("package", item.packageName);
            intent.putExtra("label", item.label);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) loadApps();
        if (store != null) refreshSelected();
    }

    private void refreshSelected() {
        String pkg = store.getSelectedGamePackage();
        String label = store.getSelectedGameLabel();
        if (pkg == null || pkg.isEmpty()) {
            selectedText.setText("Nenhum jogo selecionado ainda.");
        } else {
            selectedText.setText("Selecionado: " + (label == null || label.isEmpty() ? pkg : label));
        }
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> infos = pm.queryIntentActivities(launcher, 0);
        List<AppItem> items = new ArrayList<>();
        Set<String> added = new HashSet<>();
        for (ResolveInfo info : infos) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (getPackageName().equals(pkg) || !added.add(pkg)) continue;
            String label = String.valueOf(info.loadLabel(pm));
            boolean isGame = false;
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                isGame = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags & ApplicationInfo.FLAG_IS_GAME) != 0;
            } catch (Throwable ignored) {}
            items.add(new AppItem(label, pkg, info.loadIcon(pm), store.hasProfile(pkg), isGame));
        }
        items.sort(Comparator
                .comparing((AppItem a) -> !a.isGame)
                .thenComparing(a -> a.label.toLowerCase()));
        adapter.setItems(items);
        countText.setText(items.size() + " apps encontrados • jogos detectados aparecem primeiro");
    }
}
