package com.vanta.gametools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class FpsGraphView extends View {
    private final Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Float> values = new ArrayList<>();

    public FpsGraphView(Context context) { super(context); init(); }
    public FpsGraphView(Context context, AttributeSet attrs) { super(context, attrs); init(); }

    private void init() {
        gridPaint.setColor(Color.rgb(48, 52, 62));
        gridPaint.setStrokeWidth(dp(1));
        linePaint.setColor(Color.rgb(242, 106, 46));
        linePaint.setStrokeWidth(dp(2));
        linePaint.setStyle(Paint.Style.STROKE);
        textPaint.setColor(Color.rgb(156, 163, 175));
        textPaint.setTextSize(dp(10));
    }

    public void addValue(float fps) {
        if (fps <= 0 || Float.isNaN(fps) || Float.isInfinite(fps)) return;
        values.add(fps);
        while (values.size() > 60) values.remove(0);
        invalidate();
    }

    public void clear() {
        values.clear();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        for (int i = 1; i <= 3; i++) {
            float y = h * i / 4f;
            canvas.drawLine(0, y, w, y, gridPaint);
        }
        canvas.drawText("90", dp(4), dp(12), textPaint);
        canvas.drawText("60", dp(4), h * .34f, textPaint);
        canvas.drawText("30", dp(4), h * .68f, textPaint);
        if (values.size() < 2) return;
        float max = 90f;
        for (float v : values) if (v > max) max = Math.min(144f, v);
        Path path = new Path();
        float dx = w / Math.max(1, values.size() - 1);
        for (int i = 0; i < values.size(); i++) {
            float x = i * dx;
            float y = h - (Math.min(max, values.get(i)) / max) * h;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        canvas.drawPath(path, linePaint);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
