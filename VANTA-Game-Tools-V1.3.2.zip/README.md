# VANTA Game Tools V1.3.2

Hotfix: corrige crash ao abrir o perfil do jogo causado por incompatibilidade entre SwitchMaterial no XML e MaterialSwitch no Java. Mantém o backend Shizuku/Shell e telemetria da V1.3.1.

# VANTA Game Tools V1.3.1

Compatibilidade Shizuku revisada:
- execução via AIDL direto, sem reflexão;
- /system/bin/sh absoluto;
- fallback shell por stdin;
- diagnóstico mostra a estratégia de shell usada;
- mantém overlay, seleção de jogo, perfis e telemetria da V1.3.
